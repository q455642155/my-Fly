# 36Kr
这是流应用版本的36Kr客户端，目前已集成在360手机助手。

## 核心功能
1.通过rss订阅，读取最新的文章信息；

2.本地缓存已下载的文章内容，在无网络环境下，也可以离线阅读；

3.支持将优秀文章分享到朋友圈

4.支持根据网络条件，决定是否下载图片

5.支持清除本地缓存

6.支持流式下载，边下边用


## 软件截图
<img src="https://raw.githubusercontent.com/dcloudio/casecode/master/screenshots/36kr.png" width="320" />
