define(function(require, exports, module) {
	var pageHepler = require('../common/page-helper');
	var self = exports;

	pageHepler.init({
		handler: self
	});
});