define(function(require, exports, module) {
	var self = exports;
	self.test = function() {
		console.log('test');
	};
});