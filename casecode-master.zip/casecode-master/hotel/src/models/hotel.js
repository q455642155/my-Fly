define(function(require, exports, module) {
	var self = exports;
	
});