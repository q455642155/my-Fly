<script>
	export default {
		onLaunch: function () {
			console.log('App Launch')
		},
		onShow: function () {
			console.log('App Show')
		},
		onHide: function () {
			console.log('App Hide')
		}
	}
</script>

<style>
	/* uni.css - 通用组件、模板样式库，可以当作一套ui库应用 */
	@import "./common/uni.css";
	/*每个页面公共css */
	*{
		fontFamily: "PingFang-SC-Regular";
	}
	/* #ifdef APP-PLUS*/
	.content{
		height: calc(100% - var(--status-bar-height) + 44upx);
		min-height: calc(100vh - var(--status-bar-height) + 44upx);
		overflow:auto;
		background-color: #f4f4f4;
	}
	/* #endif */
	/* #ifdef MP-WEIXIN*/
	.content{
		height: 100%;
		min-height: 100vh;
		overflow:auto;
		background-color: #f4f4f4;
	}
	/* #endif */
	.uni-body{
		background: #f4f4f4;
	}
	/* 共用样式 */
	.style-flex{
		display: flex;
	}
	.style-flex_js_sp{
		justify-content: space-between;
	}
	.style-flex_js-ct{
		justify-content: center;
	}
	.style-flex_js-sa{
		justify-content: space-around;
	}
	.style-flex_ai-ct{
		align-items: center;
	}
	.style-flex-column{
		flex-direction: column;
	}
	.style-flex-wrap{
		flex-wrap: wrap;
	}
	.style-title{
		text-align: left;
		margin-left: 50upx;
	}
	.style-title_left{
		font-size: 30upx;
		color: #242424;
		margin-right: 12upx;
	}
	.style-title_right{
		font-size: 24upx;
		color: #888;
	}
	.btn-group button{
		width: 100%;
		border-radius: 45upx;
		margin-bottom: 30upx;
	}
	.btn-group button[type=primary]{
		color: #fff;
		background-color: #3c7ef6;
	}
	.btn-group button[type=primary][plain]{
		color: #3c7ef6;
		border: 1px solid #3c7ef6;
		background-color: rgba(0,0,0,0);
	}
	.btn-group button[type=danger]{
		color: #fff;
		background-color: #fd6768;
	}
	.btn-group button[type=danger][plain]{
		color: #fd6768;
		border: 1px solid #fd6768;
		background-color: rgba(0,0,0,0);
	}
</style>
