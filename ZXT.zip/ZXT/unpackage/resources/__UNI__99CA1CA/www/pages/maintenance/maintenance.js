
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"maintenance-menu-img{ width: ",[0,650],"; height: ",[0,280],"; margin-top: ",[0,30],"; }\n",],undefined,{path:"./pages/maintenance/maintenance.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/maintenance/maintenance.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      