
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"style-login.",[1],"data-v-4c137b66{ margin: 0 ",[0,110],"; }\n.",[1],"style-login-line.",[1],"data-v-4c137b66{ border-bottom: 1px solid #c3c3c3; padding-bottom: ",[0,26],"; margin-bottom: ",[0,58],"; }\n.",[1],"style-login-line+.",[1],"style-login-line.",[1],"data-v-4c137b66{ padding-bottom: ",[0,10],"; }\n.",[1],"ipt-group-logo_prev.",[1],"data-v-4c137b66{ width: ",[0,36],"; height: ",[0,36],"; margin-right: ",[0,20],"; }\n.",[1],"ipt-group-logo_prev.",[1],"data-v-4c137b66:after{ content:\x27\x27; }\n.",[1],"zone.",[1],"data-v-4c137b66{ color: #7d7d7d; font-size: ",[0,30],"; line-height: ",[0,30],"; }\n.",[1],"zone.",[1],"data-v-4c137b66:after{ content: \x27\x27; width: 1px; height: ",[0,30],"; background: #c3c3c3; margin: 0 ",[0,10],"; }\n.",[1],"ipt-group-logo_after.",[1],"data-v-4c137b66{ width: ",[0,15],"; height: ",[0,9],"; margin-left: ",[0,5],"; }\n.",[1],"ipt.",[1],"data-v-4c137b66{ font-size: ",[0,28],"; }\n.",[1],"ipt-sec.",[1],"data-v-4c137b66{ max-width: ",[0,280],"; }\n.",[1],"btn-sec.",[1],"data-v-4c137b66{ width: ",[0,180],"; height: ",[0,70],"; line-height: ",[0,70],"; font-size: ",[0,28],"; color: #3c7ef6; text-align: center; border: 1px solid #3c7ef6; border-radius: ",[0,10],"; margin-right: ",[0,10],"; }\n.",[1],"btn-submit.",[1],"data-v-4c137b66{ background: #3c7ef6; color:#fff; border-radius: ",[0,45],"; }\n.",[1],"a-group.",[1],"data-v-4c137b66{ margin-top: ",[0,40],"; }\n.",[1],"btn-a.",[1],"data-v-4c137b66{ color: #3c7ef6; font-size: ",[0,32],"; }\n.",[1],"btn-a.",[1],"data-v-4c137b66:first-child{ margin-left: ",[0,20],"; }\n.",[1],"btn-a.",[1],"data-v-4c137b66:last-child{ margin-right: ",[0,20],"; }\n",],undefined,{path:"./pages/login-phone/login-phone.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/login-phone/login-phone.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      