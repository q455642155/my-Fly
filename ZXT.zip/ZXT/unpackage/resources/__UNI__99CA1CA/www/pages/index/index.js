
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"content{ text-align: center; }\n.",[1],"swiper-item{ height: 140px !important; margin-top: 5px; }\n.",[1],"swiper-item.",[1],"active{ height: 100% !important; margin-top: 0; }\n.",[1],"swiper-item-view\x3e.",[1],"img{ height: 140px; width: ",[0,670],"; }\n.",[1],"swiper-item.",[1],"active\x3e.",[1],"swiper-item-view\x3e.",[1],"img{ height: 150px; }\n.",[1],"uni-swiper-dots .",[1],"uni-swiper-dot{ width: 13px; height: 3px; border-radius: initial; }\n.",[1],"main{ background: #fff; padding-bottom: ",[0,40],"; }\n.",[1],"main-menu{ margin-top: ",[0,40],"; }\n.",[1],"main-menu-list{ margin-top: ",[0,20],"; }\n.",[1],"main-menu-list-start{ margin-left: ",[0,75],"; }\n.",[1],"main-menu-list-end{ margin-right: ",[0,75],"; }\n.",[1],"main-img-content{ height: ",[0,135],"; }\n.",[1],"main-menu-img{ width: ",[0,135],"; height: ",[0,135],"; }\n.",[1],"main-menu-text_header{ font-size: ",[0,26],"; color: #242424; margin: ",[0,20]," 0 ",[0,14]," 0; }\n.",[1],"main-menu-text_body{ font-size: ",[0,22],"; color: #999; }\n.",[1],"menu-list{ margin-top: ",[0,28],"; }\n.",[1],"nav-menu{ width: ",[0,710],"; background: #fff; margin-top: ",[0,20],"; padding: ",[0,24]," 0; border-radius: ",[0,5],"; }\n.",[1],"nav-menu-text_header{ font-size: ",[0,26],"; color: #242424; margin: ",[0,16]," 0 0 0; }\n.",[1],"nav-img-content{ height: ",[0,63],"; }\n.",[1],"nav-menu-img{ width: ",[0,63],"; height: ",[0,63],"; }\n",],undefined,{path:"./pages/index/index.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/index/index.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      