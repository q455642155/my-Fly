
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"filter-body{ height: calc(100vh - ",[0,170],"); }\n.",[1],"filter-body-section-header{ font-size: ",[0,30],"; color: #7d7d7d; line-height: ",[0,30],"; height: ",[0,30],"; margin-bottom: ",[0,30],"; }\n.",[1],"filter-body-section{ padding: ",[0,40]," ",[0,30]," ",[0,30]," ",[0,30],"; }\n.",[1],"filter-body-section:not(:last-child){ border-bottom: 1px solid #f7f7f7; }\n.",[1],"filter-footer{ position: fixed; bottom: 0; left: 0; right: 0; }\n.",[1],"filter-footer .",[1],"btn{ height: ",[0,80],"; line-height: ",[0,80],"; width: 50%; }\n.",[1],"btn{ font-size: ",[0,34],"; text-align: center; }\n.",[1],"btn-default{ background: #F4F4F4; color:#3c7ef6; border-top: #c3c3c3; }\n.",[1],"btn-primary{ background: #3c7ef6; color:#fff; }\n.",[1],"search-header { height: ",[0,110],"; background: #fff; }\n.",[1],"search-header-filter-text { font-size: ",[0,30],"; color: #7d7d7d; }\n.",[1],"search-header-filter-icon { width: ",[0,24],"; height: ",[0,24],"; }\n.",[1],"search-header-filter-icon2 { width: ",[0,36],"; height: ",[0,36],"; }\n.",[1],"search-header-filter-btn { font-size: ",[0,30],"; color: #3c7ef6; }\n",],undefined,{path:"./pages/maintain/maintain.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/maintain/maintain.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      