
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"style-login.",[1],"data-v-a7fe5b98{ margin: 0 ",[0,110],"; }\n.",[1],"style-login-line.",[1],"data-v-a7fe5b98{ border-bottom: 1px solid #c3c3c3; padding-bottom: ",[0,26],"; margin-bottom: ",[0,58],"; }\n.",[1],"style-login-line+.",[1],"style-login-line.",[1],"data-v-a7fe5b98{ padding-bottom: ",[0,10],"; }\n.",[1],"ipt-group-logo_prev.",[1],"data-v-a7fe5b98{ width: ",[0,36],"; height: ",[0,36],"; margin-right: ",[0,20],"; }\n.",[1],"zone.",[1],"data-v-a7fe5b98{ color: #7d7d7d; font-size: ",[0,30],"; style-login-line-height: ",[0,30],"; }\n.",[1],"zone.",[1],"data-v-a7fe5b98:after{ content: \x27\x27; width: 1px; height: ",[0,30],"; background: #c3c3c3; margin: 0 ",[0,10],"; }\n.",[1],"ipt-group-logo_after.",[1],"data-v-a7fe5b98{ width: ",[0,15],"; height: ",[0,9],"; margin-left: ",[0,5],"; }\n.",[1],"ipt.",[1],"data-v-a7fe5b98{ font-size: ",[0,28],"; }\n.",[1],"ipt-sec.",[1],"data-v-a7fe5b98{ max-width: ",[0,280],"; }\n.",[1],"btn-sec.",[1],"data-v-a7fe5b98{ width: ",[0,180],"; height: ",[0,70],"; line-height: ",[0,70],"; font-size: ",[0,28],"; color: #3c7ef6; text-align: center; border: 1px solid #3c7ef6; border-radius: ",[0,10],"; margin-right: ",[0,10],"; }\n.",[1],"btn-submit.",[1],"data-v-a7fe5b98{ background: #3c7ef6; color:#fff; border-radius: ",[0,45],"; }\n.",[1],"a-group.",[1],"data-v-a7fe5b98{ margin-top: ",[0,40],"; }\n.",[1],"btn-a.",[1],"data-v-a7fe5b98{ color: #3c7ef6; font-size: ",[0,32],"; }\n.",[1],"btn-a.",[1],"data-v-a7fe5b98:first-child{ margin-left: ",[0,20],"; }\n.",[1],"btn-a.",[1],"data-v-a7fe5b98:last-child{ margin-right: ",[0,20],"; }\n",],undefined,{path:"./pages/register/register.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/register/register.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      