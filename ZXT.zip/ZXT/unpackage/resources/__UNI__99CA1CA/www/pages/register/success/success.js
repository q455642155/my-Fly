
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"success-img{ width: ",[0,420],"; height: ",[0,307],"; margin-top: ",[0,133],"; }\n.",[1],"success-text{ color:#7d7d7d; font-size: ",[0,26],"; margin-top: ",[0,25],"; }\n.",[1],"text-box{ width: ",[0,493],"; font-size: ",[0,26],"; color:rgb(125,125,125); margin-top: ",[0,103],"; }\n.",[1],"red{ color: #f14456; }\n.",[1],"btn-group{ margin: ",[0,38],"; }\n.",[1],"btn-group .",[1],"_button{ width: ",[0,530],"; border-radius: ",[0,45],"; margin-bottom: ",[0,30],"; }\n.",[1],"btn-group .",[1],"_button[type\x3dprimary]{ color: #fff; background-color: #3c7ef6; }\n.",[1],"btn-group .",[1],"_button[type\x3dprimary][plain]{ color: #3c7ef6; border: 1px solid #3c7ef6; background-color: rgba(0,0,0,0); }\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/register/success/success.wxss:33:21)",{path:"./pages/register/success/success.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/register/success/success.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      