
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"step-box.",[1],"data-v-997b6f96{ padding-top: ",[0,30],"; }\n.",[1],"style-white-box.",[1],"data-v-997b6f96{ background: #fff; margin: ",[0,30]," 0 ",[0,50]," 0; padding: ",[0,30]," ",[0,60],"; }\n.",[1],"style-login-line.",[1],"data-v-997b6f96:first-child{ border-bottom: 1px solid #c3c3c3; padding-bottom: ",[0,26],"; margin-bottom: ",[0,30],"; }\n.",[1],"title.",[1],"data-v-997b6f96{ font-size: ",[0,30],"; color:#7d7d7d; margin-right: ",[0,32],"; width: ",[0,120],"; }\n.",[1],"lable-phone.",[1],"data-v-997b6f96{ font-size: ",[0,30],"; color: #414141; }\n.",[1],"ipt.",[1],"data-v-997b6f96{ font-size: ",[0,28],"; }\n.",[1],"btn-sec.",[1],"data-v-997b6f96{ height: ",[0,28],"; line-height: ",[0,28],"; font-size: ",[0,28],"; color: #3c7ef6; text-align: center; border-bottom: 1px solid #3c7ef6; margin-right: ",[0,10],"; }\n.",[1],"btn-submit.",[1],"data-v-997b6f96{ width: ",[0,630],"; background: #3c7ef6; color:#fff; border-radius: ",[0,45],"; }\n",],undefined,{path:"./pages/co-auth/step1/step1.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/co-auth/step1/step1.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      