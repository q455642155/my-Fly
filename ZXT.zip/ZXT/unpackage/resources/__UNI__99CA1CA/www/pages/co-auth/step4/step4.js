
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"step-box.",[1],"data-v-6083e75c{ padding-top: ",[0,30],"; }\n.",[1],"success-img.",[1],"data-v-6083e75c{ width: ",[0,400],"; height: ",[0,300],"; margin-top: ",[0,133],"; }\n.",[1],"success-text.",[1],"data-v-6083e75c{ color:#7d7d7d; font-size: ",[0,26],"; margin-top: ",[0,25],"; }\n.",[1],"success-text-child.",[1],"data-v-6083e75c{ margin-top: ",[0,102],"; font-size: ",[0,26],"; line-height: ",[0,26],"; color:#7d7d7d; }\n.",[1],"btn-group.",[1],"data-v-6083e75c{ margin-top: ",[0,30],"; }\n.",[1],"btn-submit.",[1],"data-v-6083e75c{ width: ",[0,630],"; background: #3c7ef6; color:#fff; border-radius: ",[0,45],"; }\n",],undefined,{path:"./pages/co-auth/step4/step4.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/co-auth/step4/step4.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      