
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"record-li-title{ font-size: ",[0,30],"; height: ",[0,30],"; line-height: ",[0,30],"; color: #3c7ef6; }\n.",[1],"record-li-box{ background: #fff; margin-top: ",[0,10],"; border-radius: ",[0,5],"; }\n.",[1],"record-li-box-header{ font-size: ",[0,32],"; height: ",[0,32],"; line-height: ",[0,32],"; padding: ",[0,30]," ",[0,40]," ",[0,20]," ",[0,40],"; }\n.",[1],"record-li-box-body{ padding: ",[0,30]," ",[0,40],"; border-top: 1px solid #c3c3c3; border-bottom: 1px solid #c3c3c3; }\n.",[1],"record-li-box-body .",[1],"l-li:not(:last-child){ margin-bottom: ",[0,38],"; }\n.",[1],"label{ font-size: ",[0,28],"; height: ",[0,28],"; line-height: ",[0,28],"; color: #7d7d7d; width: ",[0,84],"; margin-right: ",[0,66],"; }\n.",[1],"text{ font-size: ",[0,32],"; height: ",[0,32],"; line-height: ",[0,32],"; color: #414141; }\n.",[1],"record-li-box-footer{ padding: ",[0,30]," ",[0,40],"; }\n.",[1],"scroll-Y{ width: ",[0,400],"; height: ",[0,120],"; }\n.",[1],"textarea{ min-height: ",[0,120],"; background: #ececec; word-break: break-all; padding: ",[0,10],"; font-size: ",[0,24],"; color: #414141; }\n.",[1],"record-ul{ padding: ",[0,40]," ",[0,50],"; }\n.",[1],"record-li:not(:first-child){ margin-top: ",[0,60],"; }\n",],undefined,{path:"./pages/maintainrecord/maintainrecord.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/maintainrecord/maintainrecord.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      