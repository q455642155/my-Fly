
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"detail-section { margin-top: ",[0,30],"; padding: 0 ",[0,50],"; }\n.",[1],"detail-section-content { margin-top: ",[0,40],"; }\n.",[1],"detail-header { background: #3c7ef6; color: #fff; font-size: ",[0,32],"; height: ",[0,32],"; line-height: ",[0,32],"; padding: ",[0,25]," ",[0,50],"; border-radius: ",[0,5],"; }\n.",[1],"detail-body { background: #fff; }\n.",[1],"detail-body.",[1],"info { padding: 0 ",[0,48]," ",[0,18]," ",[0,48],"; }\n.",[1],"detail-body .",[1],"l-li { padding: ",[0,22]," 0; }\n.",[1],"detail-body .",[1],"l-li.",[1],"l-line:not(:last-child) { border-bottom: 1px solid #c3c3c3; }\n.",[1],"detail-body .",[1],"l-li\x3e.",[1],"label { width: ",[0,120],"; color: #7d7d7d; font-size: ",[0,28],"; height: ",[0,28],"; line-height: ",[0,28],"; margin-right: ",[0,40],"; }\n.",[1],"detail-body .",[1],"l-li\x3e.",[1],"text { color: #414141; font-size: ",[0,32],"; line-height: ",[0,32],"; width: ",[0,400],"; }\n.",[1],"detail-body .",[1],"red { color: #f02c43; }\n.",[1],"detail-section-content-box{ margin-bottom: ",[0,30],"; }\n.",[1],"scroll-Y{ width: ",[0,400],"; height: ",[0,120],"; }\n.",[1],"textarea{ min-height: ",[0,120],"; background: #ececec; word-break: break-all; padding: ",[0,10],"; font-size: ",[0,24],"; color: #414141; }\n",],undefined,{path:"./pages/maintaindetail2/maintaindetail2.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/maintaindetail2/maintaindetail2.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      