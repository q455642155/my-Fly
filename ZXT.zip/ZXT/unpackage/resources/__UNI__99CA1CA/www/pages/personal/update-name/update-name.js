
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"ipt-group{ margin: ",[0,50]," 0; }\n.",[1],"ipt{ width: ",[0,630],"; border-radius: ",[0,10],"; background: #fff; font-size: ",[0,30],"; padding: ",[0,20]," ",[0,20],"; }\n",],undefined,{path:"./pages/personal/update-name/update-name.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/personal/update-name/update-name.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      