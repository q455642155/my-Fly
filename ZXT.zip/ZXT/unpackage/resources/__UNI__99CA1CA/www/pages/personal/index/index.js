
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"style-body{ margin-top: ",[0,-146],"; }\n.",[1],"head-bg{ width: ",[0,750],"; height: ",[0,200],"; }\n.",[1],"box{ width: ",[0,630],"; border-radius: ",[0,10],"; background: #FFFFFF; -webkit-box-shadow: 0 0 18px rgba(60, 126, 246, 0.3); box-shadow: 0 0 18px rgba(60, 126, 246, 0.3); -webkit-box-sizing: border-box; box-sizing: border-box; margin-bottom: ",[0,50],"; }\n.",[1],"box-1{ padding: ",[0,55]," ",[0,30],"; }\n.",[1],"box-info{ margin-left: ",[0,38],"; }\n.",[1],"box-img{ width: ",[0,136],"; height: ",[0,136],"; border-radius: 50%; -webkit-box-shadow: 0 0 0px ",[0,10]," rgba(60, 126, 246, 0.2); box-shadow: 0 0 0px ",[0,10]," rgba(60, 126, 246, 0.2); }\n.",[1],"box-info-name{ font-size: ",[0,30],"; line-height: ",[0,30],"; color: #414141; margin-bottom: ",[0,32],"; }\n.",[1],"box-info-local-text{ font-size: ",[0,24],"; color: #7d7d7d; }\n.",[1],"box-info-local-img{ width: ",[0,28],"; height: ",[0,28],"; margin-right: ",[0,10],"; }\n.",[1],"box-2{ padding: ",[0,38]," ",[0,30],"; }\n.",[1],"box-2-text{ font-size: ",[0,32],"; color: #414141; }\n.",[1],"box-2-switch{ height: ",[0,34],"; }\n.",[1],"box-3{ padding: ",[0,30]," ",[0,28],"; }\n.",[1],"box-3-item{ padding: ",[0,40]," 0; }\n.",[1],"axb-line{ border-bottom: ",[0,1]," solid rgba(195, 195, 195, 0.6); }\n.",[1],"left-img{ width: ",[0,60],"; height: ",[0,60],"; margin-right: ",[0,20],"; }\n.",[1],"right-img{ width: ",[0,24],"; height: ",[0,24],"; }\n",],undefined,{path:"./pages/personal/index/index.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/personal/index/index.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      