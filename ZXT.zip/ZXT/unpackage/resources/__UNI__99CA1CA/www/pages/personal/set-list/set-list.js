
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"box { background: #fff; margin-top: ",[0,30],"; }\n.",[1],"axb-line { border-bottom: ",[0,1]," solid rgba(195, 195, 195, 0.6); }\n.",[1],"left-text { font-size: ",[0,30],"; color: #414141; }\n.",[1],"right-avatar { width: ",[0,120],"; height: ",[0,120],"; border-radius: 50%; margin-right: ",[0,20],"; }\n.",[1],"right-img { width: ",[0,24],"; height: ",[0,24],"; }\n.",[1],"right-title { font-size: ",[0,26],"; color: #7d7d7d; }\n.",[1],"set-list-box-item{ padding: ",[0,40]," ",[0,50],"; }\n",],undefined,{path:"./pages/personal/set-list/set-list.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/personal/set-list/set-list.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      