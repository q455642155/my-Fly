<template>
	<view class="filter-header style-flex style-flex_js_sp style-flex_ai-ct">
		<text class="filter-text">筛选</text>
		<image class="filter-icon_close" src="../../static/img/close@3x.png" mode="" @tap="close"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			close:function(){
				this.$emit('close')
			}
		}
	}
</script>

<style>
	.filter-header{
		height: 90upx;
		background: #F4F4F4;
		border-bottom: 1px solid #c3c3c3;
		box-sizing: border-box;
	}
	.filter-text{
		font-size: 34upx;
		color: #3c7ef6;
		margin-left: 30upx;
	}
	.filter-icon_close{
		width: 30upx;
		height: 30upx;
		margin-right: 30upx;
	}
</style>
