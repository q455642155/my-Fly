<template>
	<view class="style-steps style-flex style-flex-column">
		<view class="step-imgs style-flex style-flex_ai-ct">
			<image class="steps-step-img" src="/static/img/co/icon01_highlight@2x.png" mode=""></image>
			<image class="steps-step-line" :src="getStepLine1" mode=""></image>
			<image class="steps-step-img" :src="getStepImg1" mode=""></image>
			<image class="steps-step-line" :src="getStepLine2" mode=""></image>
			<image class="steps-step-img" :src="getStepImg2" mode=""></image>
			<image class="steps-step-line" :src="getStepLine3" mode=""></image>
			<image class="steps-step-img"  :src="getStepImg3" mode=""></image>
		</view>
		<view class="step-texts style-flex style-flex_ai-ct style-flex_js_sp">
			<view class="steps-step-text">
				<text class="step-text step-text_active">手机认证</text>

			</view>
			<view class="steps-step-text">
				<text class="step-text" :class="{'step-text_active':step>1}">上传信息</text>

			</view>
			<view class="steps-step-text">
				<text class="step-text" :class="{'step-text_active':step>2}">填写证照</text>

			</view>
			<view class="steps-step-text">
				<text class="step-text" :class="{'step-text_active':step>3}">完成</text>

			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:{
			step:{
				type:Number,
				default:1
			}
		},
		data() {
			return {
				
			};
		},
		computed:{
			getStepLine1(){
				return this.step>1?'/static/img/co/line1@2x.png':'/static/img/co/line2@2x.png'
			},
			getStepLine2(){
				return this.step>2?'/static/img/co/line1@2x.png':'/static/img/co/line2@2x.png'
			},
			getStepLine3(){
				return this.step>3?'/static/img/co/line1@2x.png':'/static/img/co/line2@2x.png'
			},
			getStepImg1(){
				return this.step>1?'/static/img/co/icon02_highlight@2x.png':'/static/img/co/icon02_default@2x.png'
			},
			getStepImg2(){
				return this.step>2?'/static/img/co/icon03_highlight@2x.png':'/static/img/co/icon03_default@2x.png'
			},
			getStepImg3(){
				return this.step>3?'/static/img/co/icon04_highlight@2x.png':'/static/img/co/icon04_default@2x.png'
			}
		}
	}
</script>

<style>
	.style-steps{
		padding: 48upx 80upx;
		background: #fff;
	}
	.step-imgs{
		padding-left: 14upx;
	}
	.steps-step-img{
		width: 84upx;
		height: 84upx;
	}
	.steps-step-line{
		width: 80upx;
		height: 4upx;
	}
	.step-texts{
		margin-top: 14upx;
	}
	.steps-step-text{
		text-align: center;
		font-size: 28upx;
	}
	.steps-step-text:not(:first-child) .step-text{
		margin-left: -50upx;
	}
	.step-text{
		color:#7d7d7d;
	}
	.step-text_active{
		color:#3c7ef6;
	}
</style>
