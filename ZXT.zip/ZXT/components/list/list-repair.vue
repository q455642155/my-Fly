<template>
	<view>
		<view class="list-item" v-for="(item,index) in getList" :key="index" @tap="handleClick(item)">
			<view class="list-item-top style-flex style-flex_js_sp">
				<view class="title">
					<text class="title-text">{{item.areaDes}}</text>
				</view>
				<view class="statu" :class="{'statu-danger': item.mStatus==1,'statu-success':item.mStatus==2}">
					<text class="statu-text">{{item.mStatusText}}</text>
				</view>
			</view>
			<view class="list-body">
				<view class="ul style-flex">
					<view class="li label">设备代码</view>
					<view class="li">{{item.equipmentCode}}</view>
				</view>
				<view class="ul style-flex">
					<view class="li label">设备大类</view>
					<view class="li text">{{item.equipmentTypeDes}}</view>
				</view>
				<view class="ul style-flex">
					<view class="li label">报修单号</view>
					<view class="li text">{{item.mtFormCode}}</view>
				</view>
				<view class="ul style-flex">
					<view class="li label">报修日期</view>
					<view class="li text">{{item.applyDt}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:{
			list:{
				type:Array,
				default: []
			}
		},
		computed:{
			getList(){
				const list = this.list.map((item)=>{
					item.mStatusText=this.getStatuMsg(item.mStatus)
					return item
				})
				return list
			}
		},
		methods:{
			handleClick(val){
				uni.navigateTo({
					url: `../../pages/repairdetail/repairdetail?id=${val.mtFormCode}&status=${val.mStatus}&title=${val.areaDes}`
				})
			},
			getStatuMsg(value){
				let val = Number(value)
				return val=== 0?'未签核':val === 1?'签核中':'已签核'
			}
		}
	}
</script>

<style>
.list-item {
		margin: 30upx 0;
		height: 100%;
		width: 100%;
		text-align: center;
		background:#FFF;
	}
	.list-item-top{
		width: 650upx;
		border-bottom: 1upx solid #c3c3c3;
		padding: 36upx 0 24upx 0;
		margin-left: 50upx;
	}
	.title-text{
		color: #508CEE;
		font-size: 32upx;
	}
	.statu{
		color: #7d7d7d;
	}
	.statu-success{
		color: #0c9a48;
	}
	.statu-danger{
		color: #f02c43;
	}
	.list-body{
		margin: 32upx 50upx 50upx 50upx;
	}
	.ul{
		margin-top: 38upx;	
	}
	.li{
		margin-right: 40upx;
		font-size: 28upx;
		height: 28upx;
		line-height: 28upx;
		color: #414141;
	}
	.li.label{
		color: #7d7d7d;
	}
</style>
