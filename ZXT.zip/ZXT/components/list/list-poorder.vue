<template>
	<view>
		<view class="list-item" v-for="(item,index) in list" :key="index" @tap="handleClick(item)">
			<view class="list-item-top style-flex style-flex_js_sp">
				<view class="title">
					<text class="title-text">{{item.companyName}}</text>
				</view>
				<view class="statu statu-success">
					<text class="statu-text"></text>
				</view>
			</view>
			<view class="list-body">
				<view class="ul style-flex">
					<view class="li label">订单编号</view>
					<view class="li">{{item.poBillno}}</view>
				</view>
				<view class="ul style-flex">
					<view class="li label">订单日期</view>
					<view class="li text">{{item.poDate}}</view>
				</view>
				<view class="ul style-flex">
					<view class="li label">采购总价</view>
					<view class="li text"><text class="red money">{{item.dealTotalAmount}}</text>{{item.currCode}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:{
			list:{
				type:Array,
				default: []
			}
		},
		methods:{
			handleClick:function(item){
				console.log('进入详情',item)
				uni.navigateTo({
					url: '../../pages/podetail/podetail?id='+item.poBillno
				})
			}
		}
	}
</script>

<style>
.list-item {
		margin: 30upx 0;
		height: 100%;
		width: 100%;
		text-align: center;
		background:#FFF;
	}
	.list-item-top{
		width: 650upx;
		border-bottom: 1upx solid #c3c3c3;
		padding: 36upx 0 24upx 0;
		margin-left: 50upx;
	}
	.title-text{
		color: #508CEE;
		font-size: 32upx;
	}
	.statu{
		color: #7d7d7d;
	}
	.statu-success{
		color: #0c9a48;
	}
	.statu-danger{
		color: #f02c43;
	}
	.list-body{
		margin: 32upx 50upx 50upx 50upx;
	}
	.ul{
		margin-top: 38upx;	
	}
	.li{
		margin-right: 40upx;
		font-size: 28upx;
		height: 28upx;
		line-height: 28upx;
		color: #414141;
	}
	.li.label{
		color: #7d7d7d;
	}
	.red{
		color: #f02c43;
	}
	.money{
		font-size:34upx;
		margin-right: 10upx;
	}
</style>
