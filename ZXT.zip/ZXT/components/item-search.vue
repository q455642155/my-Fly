<template>
	<view class="" @tap="handleFilter()">
		<text class="search-header-filter-text">{{title}}</text>
		<image class="search-header-filter-icon" :src="searchIcons[getStatus]" mode=""></image>
	</view>
</template>

<script>
	export default {
		props:{
			title: String,
			status: { // 状态 0 默认 1 高到低 2 低到高
				type:String,
				default:''
			}
		},
		data() {
			return {
				searchIcons:[
					"../../static/img/arrow_default@3x.png",
					"../../static/img/arrow_down@3x.png",
					"../../static/img/arrow_up@3x.png"
				],
			};
		},
		computed:{
			getStatus:function(){
				return this.status==='desc'?1:this.status==='asc'?2:0
			}
		},
		methods:{
			handleFilter:function(){
				let res = this.getStatus===2?1 : this.getStatus+1
				let reString = res===1?'desc':res===2?'asc':''
				this.$emit('statu-change', reString)
			},
		}
	}
</script>

<style>
	.search-header-filter-text{
		font-size: 30upx;
		color: #7d7d7d;
	}
	.search-header-filter-icon{
		width: 24upx;
		height: 24upx;
	}
	.search-header-filter-icon2{
		width: 36upx;
		height: 36upx;
	}
</style>
