<template>
    <view class="iconfont" :class="['icon-'+type]" :style="{color:color,'font-size':fontSize,'line-height': lineHeight}" @click="onClick()"></view>
</template>

<script>
    export default {
        props: {
            /**
             * 图标类型
             */
            type: String,
            /**
             * 图标颜色
             */
            color: String,
            /**
             * 图标大小
             */
            size: [Number, String],
			height:[Number, String],
        },
        computed: {
            fontSize() {
                return `${this.size}px`
            },
			lineHeight(){
				return this.height?`${this.height}px`:''
			}
        },
        methods: {
            onClick() {
                this.$emit('click')
            }
        }
    }
</script>
<style scoped>
	@font-face {
	  font-family: 'iconfont';  /* project id 1003317 */
	  src: url('https://at.alicdn.com/t/font_1003317_1mttabzyd7m.eot');
	  src: url('https://at.alicdn.com/t/font_1003317_1mttabzyd7m.eot?#iefix') format('embedded-opentype'),
	  url('https://at.alicdn.com/t/font_1003317_1mttabzyd7m.woff2') format('woff2'),
	  url('https://at.alicdn.com/t/font_1003317_1mttabzyd7m.woff') format('woff'),
	  url('https://at.alicdn.com/t/font_1003317_1mttabzyd7m.ttf') format('truetype'),
	  url('https://at.alicdn.com/t/font_1003317_1mttabzyd7m.svg#iconfont') format('svg');
	}
    .iconfont {
      font-family: "iconfont" !important;
      font-size: 16px;
      font-style: normal;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
	.icon-search:before {
	  content: "\e632";
	}
	
	.icon-xiaoxi:before {
	  content: "\e88b";
	}
	
	.icon-back:before {
	  content: "\e68f";
	}
	
	.icon-shezhi:before {
	  content: "\e663";
	}
	
	.icon-sousuo:before {
	  content: "\e60f";
	}
</style>

