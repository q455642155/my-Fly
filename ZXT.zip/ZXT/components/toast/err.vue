<template>
	<view class="err-box style-flex style-flex_ai-ct style-flex-column">
		<image class="err-img" :src="imgArr[errType].src" mode=""></image>
		<text class="err-text">{{getMsg}}</text>
	</view>
</template>

<script>
	export default {
		props:{
			errType:{
				type:String,
				default:'noNetwork'
			},
			errMsg:{
				type:String,
				default: ''
			}
		},
		data() {
			return {
				imgArr:{
					'':{
						src:"../../static/img/blankpage_nodata@2x.png",
						msg:'暂无数据'
					},
					noNetwork:{
						src:"../../static/img/blankpage_network@2x.png",
						msg:'网络异常,请稍后再试'
					},
					noData:{
						src:"../../static/img/blankpage_nodata@2x.png",
						msg:'暂无数据'
					},
				}
			};
		},
		computed:{
			getMsg(){
				return this.errMsg.length>0?this.errMsg:this.imgArr[this.errType].msg
			}
		}
	}
</script>

<style>
.err-box{
	margin-top: 100upx;
}
.err-img{
	width: 370upx;
	height: 326upx;
}
.err-text{
	margin-top: 25upx;
	font-size: 26upx;
	color: #7d7d7d;
}
</style>
