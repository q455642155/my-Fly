<template>
	<view v-show="isShow" class="info-box style-flex style-flex_ai-ct style-flex_js-ct">
		<view class="info-box-mask style-flex">
		<image class="info-img" :src="imgArr[infoType].src" mode=""></image>
		<text class="info-text">{{getMsg}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		props:{
			type:{
				type:String,
				default:'success'
			},
			msg:{
				type:String,
				default: ''
			}
		},
		data() {
			return {
				isShow: false,
				infoType: this.type,
				infoMsg: this.msg,
				time: 1000,
				imgArr:{
					'':{
						src:"./static/img/blankpage_nodata@2x.png",
						msg:'暂无数据'
					},
					success:{
						src:"/static/img/login/login_icon_finish@2x.png",
						msg:'网络异常,请稍后再试'
					},
					error:{
						src:"/static/img/login/login_icon_wrong@2x.png",
						msg:'暂无数据'
					},
					notice:{
						src:"/static/img/person/icon_notice@2x.png",
						msg:'警告'
					},
				}
			};
		},
		computed:{
			getMsg(){
				return this.infoMsg.length>0?this.infoMsg:this.imgArr[this.type].msg
			}
		},
		methods:{
			show:function(type,msg,time){
				this.infoType = type?type:this.infoType
				this.infoMsg = msg?msg:this.infoMsg
				this.time = time?time:this.time
				this.isShow = true
				setTimeout(()=>{
					this.hide()
				},this.time)
			},
			hide:function(){
				this.isShow = false
			}
		}
	}
</script>

<style>
.info-box{
	position: absolute;
    z-index: 99;
    transform: translateX(-50%);
	left: 50%;
	width: 500upx;
}
.info-box-mask{
	background: rgba(0,0,0,.6);
	height: 80upx;
	line-height: 80upx;
	padding-right: 40upx;
	border-radius: 10upx;
}
.info-img{
	width: 44upx;
	height: 44upx;
	margin: 18upx 18upx 18upx 36upx;
}
.info-text{
	font-size: 34upx;
	color: #fff;
}
</style>
