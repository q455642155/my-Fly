<template name="page-head">
	<view class="style-page-head style-flex style-flex-column style-flex_ai-ct">
		<image class="head-img-bg" src="../../static/img/login/login_bg@2x.png" mode=""></image>
		<image class="head-img-logo" src="../../static/img/login/logo@2x.png" mode=""></image>
	</view>
</template>
<script>
	export default {
		name: "page-head",
		props: {
			title: {
				type: String,
				default: ""
			}
		}
	}
</script>
<style scoped>
	.head-img-bg{
		width: 750upx;
		height: 316upx;
	}
	.head-img-logo{
		width: 210upx;
		height: 210upx;
		transform: translateY(-50%);
	}
</style>