<template>
	<view>
		<view class="detail-body-ul-header">
			<view class="detail-body-ul-header-title style-flex style-flex_js_sp">
				<view class="left">物资序号:{{idx}}</view>
				<view class="right" @tap="handleShow">
					<text>{{getRightBtn}}</text>
					<image class="open-colse-icon" :src="getIcons" mode=""></image>
				</view>
			</view>
		</view>
		<view class="detail-body-ul-body">
			<view v-for="(item,idx) in details" :key="idx" v-if="idx<4" class="l-li style-flex style-flex_ai-ct">
				<view class="label">{{item.title}}</view>
				<view class="text" :class="{ red: item.isRed }">{{data[item.value]}}</view>
			</view>
			<view v-show="isShow">
				<view v-for="(item,idx) in details" :key="idx" v-if="idx>3" class="l-li style-flex style-flex_ai-ct">
					<view class="label">{{item.title}}</view>
					<view class="text" :class="{ red: item.isRed }">{{data[item.value]}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {thousandth} from '../../common/util.js'
	export default {
		props:{
			idx:{
				type:Number,
				default:1,
			},
			data:{
				type:Object,
				default: null
			}
		},
		data() {
			return {
				isShow: false,
				details: [{
					title: '料号',
					value: 'itemCode'
				}, {
					title: '品名',
					value: 'itemName'
				}, {
					title: '品牌',
					value: 'brand',
					
				}, {
					title: '规格',
					value: 'spec'
				}, {
					title: '单位',
					value: 'unit'
				}, {
					title: '数量',
					value: 'itemNum'
				}, {
					title: '单价',
					value: 'itemPrice'
				}, {
					title: '小计金额',
					value: 'totalAmount'
				}, {
					title: '实际单价',
					value: 'itemPrice',
				}, {
					title: '实际金额',
					value: 'totalAmount',
				}]
			};
		},
		computed:{
			getRightBtn:function(){
				return this.isShow? '收起':'展开'
			},
			getIcons:function(){
				return this.isShow?"../../static/img/icon_up@3x.png":"../../static/img/icon_down@3x.png"
			},
			getComData(){
				let t = this.data
				t.amount = thousandth(t.itemPrice*t.itemNum)
				return  t
			}
		},
		methods:{
			handleShow(){
				this.isShow = !this.isShow
				if(this.isShow){
					this.$emit('change-show')
				}
			},
			handleHide(){
				this.isShow = false
			},
		}
	}
</script>

<style>
	.l-li {
		padding: 22upx 0;
	}

	.l-li.l-line:not(:last-child) {
		border-bottom: 1px solid #c3c3c3;
	}

	.l-li>.label {
		width: 120upx;
		color: #7d7d7d;
		font-size: 28upx;
		height: 28upx;
		line-height: 28upx;
		margin-right: 40upx;
	}

	.l-li>.text {
		color: #414141;
		font-size: 32upx;
		height: 32upx;
		line-height: 32upx;
	}

	.l-li>.text.red {
		color: #f02c43;
	}
	/* 按钮样式 */
	.open-colse-icon{
		width: 16upx;
		height: 16upx;
	}
	/* 物资列表样式 */
	.detail-body-ul-header-title {
		padding: 40upx 30upx 22upx 50upx;
		color: #3c7ef6;
	}

	.detail-body-ul-header-title .left,
	.detail-body-ul-header-title .right {
		font-size: 30upx;
		height: 30upx;
		line-height: 30upx;
	}

	.detail-body-ul-body {
		border-top: 1px solid #C3C3C3;
		border-bottom: 1px solid #C3C3C3;
		padding: 0 50upx 30upx 50upx;
	}
	.detail-body-ul-body-name {
		margin: 0 30upx 0 50upx;
		color: #414141;
		font-size: 32upx;
		height: 32upx;
		line-height: 32upx;
		padding: 22upx 0;
		border-bottom: 1px solid #C3C3C3;
	}
	.detail-body.list .li {
		padding: 30upx 0 0 50upx;
	}

	.detail-body.list .li+.li {
		padding: 38upx 0 0 50upx;
	}
</style>
