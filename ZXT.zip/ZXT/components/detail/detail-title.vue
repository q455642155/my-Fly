<template>
	<view class="detail-title style-flex style-flex_js_sp">
		<text class="title-name">{{title}}</text>
		<text class="title-status" :class="{'statu-danger': status==1,'statu-success':status==2}">{{getStatusMsg}}</text>
	</view>
</template>

<script>
	export default {
		props: {
			title: {
				type: String,
				default: ''
			},
			status: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {

			};
		},
		computed: {
			getStatusMsg() {
				return this.status === 0 ? '未签核' : this.status === 1 ? '签核中' : '已签核'
			}
		}
	}
</script>

<style>
	.detail-title {
		background: #fff;
		padding: 35upx 50upx;
		font-size: 32upx;
		height: 32upx;
		line-height: 32upx;
		text-align: center;
		border-top: 1px solid #c3c3c3;
		box-shadow: 0 5upx 5upx rgba(214, 214, 214, 0.75);
	}
	.title-name{
		width: 480upx;
		text-align: left;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.title-status {
		font-size: 28upx;
		height: 28upx;
		line-height: 28upx;
		color: #7d7d7d;
	}

	.statu-success {
		color: #0c9a48;
	}

	.statu-danger {
		color: #f02c43;
	}
</style>
