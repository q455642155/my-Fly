<template>
	<view>
		<view class="record-li-title">保养序号: {{idx}}</view>
		<view class="record-li-box">
			<view class="record-li-box-header">
				测试项目
			</view>
			<view class="record-li-box-body">
				<view class="l-li style-flex style-flex_ai-ct">
					<view class="label">油格</view>
					<view class="text">{{data.oil}}</view>
				</view>
				<view class="l-li style-flex style-flex_ai-ct">
					<view class="label">风格</view>
					<view class="text">{{data.wind}}</view>
				</view>
				<view class="l-li style-flex style-flex_ai-ct">
					<view class="label">散热器</view>
					<view class="text">{{data.hot}}</view>
				</view>
				<view class="l-li style-flex style-flex_ai-ct">
					<view class="label">回油器</view>
					<view class="text">{{data.wind}}</view>
				</view>
				<view class="l-li style-flex style-flex_ai-ct">
					<view class="label">仪电</view>
					<view class="text">{{data.wind}}</view>
				</view>
			</view>
			<view class="record-li-box-footer style-flex">
					<view class="label">备注</view>
					<scroll-view :scroll-top="0" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
					@scroll="scroll">
					<view class="textarea">
						{{data.remark}}
					</view>
					</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:{
			idx:{
				type:Number,
				default:0
			},
			data:{
				type:Object,
				default:{
					oil:'良好或正常完成(V)',
					wind: '不良或未能完成(X)',
					hot: '需要调整(*)',
					remark:'12323124sadfhasfhaj'
				}
			}
		},
		data() {
			return {
				
			};
		}
	}
</script>

<style>
.record-li-title{
		font-size: 30upx;
		height: 30upx;
		line-height: 30upx;
		color: #3c7ef6;
	}
	.record-li-box{
		background: #fff;
		margin-top: 10upx;
		border-radius: 5upx;
	}
	.record-li-box-header{
		font-size: 32upx;
		height: 32upx;
		line-height: 32upx;
		padding: 30upx 40upx 20upx 40upx;
	}
	.record-li-box-body{
		padding: 30upx 40upx;
		border-top: 1px solid #c3c3c3;
		border-bottom: 1px solid #c3c3c3;
	}
	.record-li-box-body .l-li:not(:last-child){
		margin-bottom: 38upx;
	}
	.label{
		font-size: 28upx;
		height: 28upx;
		line-height: 28upx;
		color: #7d7d7d;
		width: 84upx;
		margin-right: 66upx;
	}
	.text{
		font-size: 32upx;
		height: 32upx;
		line-height: 32upx;
		color: #414141;
	}
	.record-li-box-footer{
		padding: 30upx 40upx;
	}
	.scroll-Y{
		width: 400upx;
		height: 120upx;
	}
	.textarea{
		min-height: 120upx;
		background: #ececec;
		word-break: break-all;
		padding: 10upx;
		font-size: 24upx;
		color: #414141;
	}
</style>
