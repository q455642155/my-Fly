<template>
	<view class="po-ul">
		<detail-item ref="detail-item" v-for="(item,idx) in data" :data="item"  :idx="idx+1" @change-show="handleShow(idx)"></detail-item>
	</view>
</template>

<script>
	import detailItem from '../../components/detail/detail-po-item.vue';
	export default {
		props: {
			data:{
				type:Array,
				default:[
					{name:'123'},
					{name:'123'}
				]
			}
		},
		components: {
			detailItem
		},
		data() {
			return {
				arr:[],
				cur: 0
			}
		},
		methods:{
			handleShow(idx){
				console.log(idx)
				if(this.cur!==idx){
					this.$refs['detail-item'][this.cur].handleHide()
				}
				this.cur = idx
			}
		}
	}
</script>

<style>
	.detail-header {
		background: #3c7ef6;
		color: #fff;
		font-size: 32upx;
		height: 32upx;
		line-height: 32upx;
		padding: 25upx 50upx;
		border-radius: 5upx;
	}

	.detail-body {
		background: #fff;
	}
</style>
