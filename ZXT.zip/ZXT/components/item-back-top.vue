<template>
	<view class="item-buck-top">
		<image v-show="isShow" class="item-buck-top-img" src="../../static/img/icon_stick@3x.png" mode="" @tap="back"></image>
	</view>
</template>

<script>
	export default {
		props:{
			isShow:{
				type: Boolean,
				default:false
			}
		},
		data() {
			return {
				
			};
		},
		methods: {
			back: function() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			}
		}
	}
</script>

<style>
	.item-buck-top {
		position: fixed;
		width: 86upx;
		height: 86upx;
		right: 50upx;
		bottom: 200upx;
		z-index: 99;
	}

	.item-buck-top-img {
		width: 86upx;
		height: 86upx;
	}
</style>
