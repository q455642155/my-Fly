<template>
	<view>
		<!-- 固定在顶部的导航栏 -->
		<uni-nav-bar fixed="true" left-icon="back" @click-left="back" backgroundColor="#3c7ef6" iconColor="#fff" color="#999">
			<view class="input-view">
				<input v-model.trim="searchtext" confirm-type="search" @confirm="confirm" maxlength=50 class="input" type="text"
				 placeholder="输入计划编号/设备名称搜索" />
				<uni-icon type="search" size="22" height="32" color="#666666" @click="confirm"></uni-icon>
			</view>
		</uni-nav-bar>
		<!-- 使用非原生导航栏后需要在页面顶部占位 -->
		<view class="space-top" style="background: #f4f4f4;">...</view>
		<!-- 主体内容 -->
		<view class="content">
			<!-- 历史记录 -->
			<view v-show="inputing" class="section history">
				<view class="history-header style-flex style-flex_js_sp">
					<text class="history-header-title">历史记录</text>
					<image class="history-header-icon" src="../../static/img/icon_delete@3x.png" mode="" @click="handleClearHistory"></image>
				</view>
				<view class="history-body style-flex style-flex-wrap">
					<text v-for="(item,idx) in searchArr" :key="idx" class="history-item" @click="bindSearchTap(item)">{{item}}</text>
				</view>
			</view>
			<!-- 列表 -->
			<view v-show="!inputing" class="section list">
				<view>
					<back-top :is-show="isShowBkTop"></back-top>
					<!-- 排序区域 -->
					<view class="search-header style-flex style-flex_ai-ct style-flex_js-sa">
						<search :title="'开始日期'" :status="planDt" @statu-change="handleSort('planDt',$event)"></search>
						<search :title="'状态'" :status="mStatus" @statu-change="handleSort('mStatus',$event)"></search>
						<search :title="'厂区'" :status="areaDes" @statu-change="handleSort('areaDes',$event)"></search>
						<view class="style-flex style-flex_ai-ct" @tap="showRightDrawer">
							<text class="search-header-filter-btn">筛选</text>
							<image class="search-header-filter-icon2" src="../../static/img/filtrate@3x.png" mode=""></image>
						</view>
					</view>
					<!-- 列表区域 -->
					<view class="list-box">
						<view class="list-view">
							<l-list :list="list"></l-list>
						</view>
						<!-- 错误提示 -->
						<l-err v-if="list.length===0&&showErr" :err-type="errType"></l-err>
						<!-- 加载更多 -->
						<uni-load-more v-if="list.length>0|!showErr" :loadingType="loadingType" :contentText="contentText"></uni-load-more>
					</view>
					<!-- 侧滑抽屉 -->
					<uni-drawer :visible="rightDrawerVisible" mode="right" :is-search="true" @close="closeRightDrawer">
						<view class="style-filter-content">
							<filter-header @close="closeRightDrawer"></filter-header>
							<scroll-view scroll-y class="filter-body">
								<view class="filter-body-section">
									<view class="filter-body-section-header">
										维保状态
									</view>
									<view class="filter-body-section-body style-flex style-flex-wrap">
										<filter-radio ref="radio1" :multi="true" :list="filterStatus" @change="radioChangeStatus"></filter-radio>
									</view>
								</view>
								<view class="filter-body-section">
									<view class="filter-body-section-header">
										开始日期
									</view>
									<view class="filter-body-section-body style-flex style-flex-wrap">
										<filter-radio ref="radio2" :list="filterSartTime" @change="radioChangeSartTime"></filter-radio>

									</view>
								</view>
								<view class="filter-body-section">
									<view class="filter-body-section-header">
										设备大类
									</view>
									<view class="filter-body-section-body style-flex style-flex-wrap">
										<filter-radio ref="radio3" :list="filterType" @change="radioChangeType"></filter-radio>

									</view>
								</view>
								<view class="filter-body-section">
									<view class="filter-body-section-header">
										厂区
									</view>
									<view class="filter-body-section-body style-flex style-flex-wrap">
										<filter-radio ref="radio4" :list="filterFactor" @change="radioChangeFactor"></filter-radio>

									</view>
								</view>
							</scroll-view>
							<view class="filter-footer style-flex">
								<view class="btn btn-default" @tap="filterReset">
									重置
								</view>
								<view class="btn btn-primary" @tap="filterSub">
									确定
								</view>
							</view>
						</view>
					</uni-drawer>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// 配置
	import {
		conf
	} from '../../common/config.js'
	// 函数
	import _ from '../../common/util.js'
	import debounce from 'lodash/debounce'
	import throttle from 'lodash/throttle'
	import orderBy from 'lodash/orderBy'
	// 函数-排序相关(维保)
	import orderHelp from '../../common/maintaince/commons-order.js'
	// 函数-筛选相关(维保)
	import filterHelp from '../../common/maintaince/commons-filter.js'
	// 函数-其它相关(维保)
	import orderMain from '../../common/maintaince/commons-main.js'
	// 搜索
	import uniNavBar from '../../components/uni-nav-bar.vue'
	import uniIcon from '../../components/uni-icon.vue'
	// 列表
	import uniLoadMore from '../../components/uni-load-more.vue'
	import uniDrawer from '../../components/uni-drawer.vue';
	import lErr from '../../components/toast/err.vue'

	import lList from '../../components/list/list-maintain.vue'
	import search from '../../components/item-search.vue'
	import backTop from '../../components/item-back-top.vue'
	// 筛选组件
	import filterHeader from '../../components/filter/filter-header.vue'
	import filterRadio from '../../components/filter/filter-radio.vue'
	export default {
		components: {
			uniNavBar,
			uniIcon,
			// 列表
			uniLoadMore,
			uniDrawer,
			lErr,
			lList,
			search,
			backTop,
			filterHeader,
			filterRadio
		},
		data() {
			return {
				isShowBkTop: false,
				//  *** 布局相关 ***//
				inputing: true, // 查询中

				// *** 搜索相关数据 ***//
				searchArr: [], // 搜索内容数组
				searchtext: '', //搜索框内容
				// *** 列表相关数据 ***//
				list: [],
				// 错误提示
				showErr: 0,
				errType: '',
				loadingType: 0,
				contentText: {
					contentdown: "上拉显示更多",
					contentrefresh: "正在加载...",
					contentnomore: "已经到底了"
				},
				// 排序顺序
				order:['planDt','mStatus','areaDes'],
				// 排序条件
				planDt: '', // 开始日期
				mStatus: '', // 状态
				areaDes: '', // 厂区
				// 抽屉
				rightDrawerVisible: false,
				//***************************筛选条件********************************/
				//筛选条件
				searchParam: {
					pageNum: 0,
					pageSize: 20,
					venCode: "VCN0021205",
					venAccount: "VCN0021205",
					dateStart: _.dateToString(_.getTime('1month')),
					dateEnd: _.dateToString(new Date()),
					equipmentType: '',
					mStatus: '',
					areaType: ''
				},
				// 最新筛选条件
				filterParam: {
					dateStart: _.dateToString(_.getTime('1month')),
					dateEnd: _.dateToString(new Date()),
					equipmentType: '',
					mStatus: '',
					areaType: ''
				},
				filterStatus: [{ // 维保状态
					name: '全部',
					value: 'all',
					checked: 0
				}, {
					name: '未签核',
					value: 0,
					checked: 0
				}, {
					name: '签核中',
					value: 1,
					checked: 0
				}, {
					name: '已签核',
					value: 2,
					checked: 0
				}],
				filterSartTime: [{ // 开始日期
					name: '过去三天',
					value: '3day',
					checked: 0
				}, {
					name: '过去一周',
					value: '1week',
					checked: 0
				}, {
					name: '过去一月',
					value: '1month',
					checked: 0
				}, {
					name: '过去半年',
					value: '6month',
					checked: 0
				}, {
					name: '过去一年',
					value: '1year',
					checked: 0
				}],
				filterType: [],
				filterFactor: [],
			};
		},
		watch: {
			searchtext: function(val) { // 监听输入框有无内容
				if (val.length === 0) {
					this.inputing = true
				}
			}
		},
		// 
		onLoad() {
			this.getCommonData()
			uni.getStorage({
				key: 'search_arr-maintain',
				success: (res) => {
					console.log(res.data);
					this.searchArr = res.data
				}
			});
		},
		onPageScroll: throttle(_.isShowBtn, 100, {
			'leading': false
		}),
		// 上拉加载更多
		async onReachBottom() {
			console.log('上拉加载')
			if (this.loadingType !== 0) {
				return;
			}
			this.loadingType = 1;
			let r = await this.getData(this.searchParam.pageNum++)
			console.log(r)
			// this.loadingType = r?0:2;
		},
		methods: {
			back() {
				uni.navigateBack({
					delta: 1
				})
			},
			// 事件-搜索记录单击
			bindSearchTap(item) {
				this.searchtext = item
				this.search(item)
			},
			search(val) {
				console.log(val)
				this.searchParam.likeCond = val
				this.initData();
				this.inputing = false
			},
			// 事件-确定搜索
			confirm() {
				// 关闭软键盘
				uni.hideKeyboard()
				if (this.searchtext.length === 0) {
					return
				}
				if (!this.searchArr.includes(this.searchtext)) {
					this.searchArr.unshift(this.searchtext)
				}
				if (this.searchArr.length > 10) {
					this.searchArr.pop()
				}
				uni.setStorage({
					key: 'search_arr-maintain',
					data: this.searchArr,
					success: () => {
						console.log('success');
					}
				});
				this.search(this.searchtext)
			},
			// 事件-清除搜索历史
			handleClearHistory() {
				const _this = this
				uni.showModal({
					title: '提示',
					content: '确认删除历史记录',
					success: function(res) {
						if (res.confirm) {
							console.log('用户点击确定');
							uni.removeStorage({
								key: 'search_arr-maintain',
								success: (res) => {
									console.log('success');
									_this.searchArr = []
								},
								fail: function(err) {
									uni.showToast({
										title: '清理失败' + err,
										duration: 2000
									});
								}
							});
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				});
			},
			// **************************************排序相关方法****************************//
			// 获取排序顺序数组
			// 获取排序顺序数组
			getSortValueArr: orderHelp.getSortValueArr,
			// 获取排序查询字符串参数
			getSortSql:orderHelp.getSortSql,
			handleSort: orderHelp.handleSort,
			// **************************************筛选相关方法****************************//
			closeRightDrawer() {
				this.rightDrawerVisible = false;
				//#ifdef APP-PLUS
				// 开启下拉刷新
				const pages = getCurrentPages();
				const page = pages[pages.length - 1];
				const currentWebview = page.$getAppWebview();
				currentWebview.setStyle({
					pullToRefresh: {
						support: true,
						style: plus.os.name === 'Android' ? 'circle' : 'default'
					}
				});
				//#endif
			},
			showRightDrawer() {
				this.rightDrawerVisible = true;
				//#ifdef APP-PLUS
				// 关闭下拉刷新
				const pages = getCurrentPages();
				const page = pages[pages.length - 1];
				const currentWebview = page.$getAppWebview();
				currentWebview.setStyle({
					pullToRefresh: {
						support: false,
						style: plus.os.name === 'Android' ? 'circle' : 'default'
					}
				});
				//#endif
			},
			// 筛选修改-状态
			radioChangeStatus:filterHelp.radioChangeStatus(3),
			// 筛选修改-时间
			radioChangeSartTime:filterHelp.radioChangeSartTime('1month'),
			// 筛选修改-类型
			radioChangeType:filterHelp.radioChangeType,
			// 筛选修改-厂区
			radioChangeFactor:filterHelp.radioChangeFactor,
			// 筛选重置
			filterReset: function() {
				for (let var1 in this.$refs) {
					this.$refs[var1].reset()
				}
				this.filterParam.mStatus = ''
				this.filterParam.dateStart = _.dateToString(_.getTime('1month'))
				this.filterParam.equipmentType = ''
				this.filterParam.areaType = ''
			},
			// 筛选提交
			filterSub() {
				this.initData()
				this.closeRightDrawer()
			},
			// ***********************************数据获取******************************//
			// 初始化获取数据
			initData: orderMain.initData,
			// 获取公共信息
			getCommonData: orderMain.getCommonData,
			// 获取数据
			getData: orderMain.getData('http://10.134.154.115:8011/mtform/getmplanlist'),
			// 筛选提交debounce
			filterSub: debounce(filterSub, 500, {
				leading: true,
				trailing: false
			})
		}
	}

	function filterSub() {
		console.log('提交')
		Object.assign(this.searchParam, this.filterParam)
		this.initData()
		this.closeRightDrawer()
	}
</script>

<style>
	@import "../../common/list.css";
	@import "../../common/search.css";
	@import "../../common/filter.css";
</style>
