<template>
	<view class="content">
		<page-head></page-head>
		<view class="style-login">
			<form @submit="formSubmit">
				<view class="style-flex style-flex-column">
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<image class="ipt-group-logo_prev" src="../../static/img/login/icon_account@2x.png" mode=""></image>
						<view class="ipt style-flex style-flex_js_sp">
							<input class="ipt-phone" name="username" v-model="username" placeholder="请输入手机号/帐号ID"/>
						</view>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<image class="ipt-group-logo_prev" src="../../static/img/login/icon-password@2x.png" mode=""></image>
						<view class="ipt style-flex style-flex_js_sp">
							<input class="ipt-sec" name="pass" placeholder="请输入密码" :password="showPassword" />
							<view class="uni-icon uni-icon-eye" :class="[!showPassword ? 'uni-active' : '']" @click="changePassword"></view>
						</view>
						<toast ref="login-toast" type="error" msg="用户名/密码错误"></toast>
					</view>
					<view class="btn-group">
						<button class="btn-submit" formType="submit">登录</button>
					</view>
					<view class="a-group style-flex style-flex_js_sp">
						<navigator url="../register/register" hover-class="navigator-hover">
							<text class="btn-a">注册新账号</text>
						</navigator>
						<navigator url="../login-phone/login-phone" open-type="redirect" hover-class="navigator-hover">
							<text class="btn-a">手机号登录</text>
						</navigator>
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	// 配置
	import {
		conf
	} from '../../common/config.js'
	import _ from '../../common/util.js'
	import debounce from 'lodash/debounce'
	import toast from '../../components/toast/toast.vue';
	//来自 graceUI 的表单验证， 使用说明见手册 http://grace.hcoder.net/doc/info/73-3.html
	var  graceChecker = require("../../common/graceChecker.js");
	export default {
		components: {
			toast
		},
		data() {
			return {
				username: '', // 用户名
				pass:'', // 密码
				showPassword: true,
			};
		},
		computed:{
		},
		methods:{
			changePassword: function () {
				this.showPassword = !this.showPassword;
			},
			formSubmit:debounce(formSubmit, 500, {leading: true,trailing: false}),
		}
	}
	// 提交
	function formSubmit(e){
		console.log(e)
		//将下列代码加入到对应的检查位置
		//定义表单规则
		var rule = [
			{name:"username", checkType : "notnull", checkRule:"",  errorMsg:"账号不能为空"},
			{name:"pass", checkType : "notnull", checkRule:"",  errorMsg:"密码不能为空"}
		];
		//进行表单检查
		var formData = e.detail.value;
		var checkRes = graceChecker.check(formData, rule);
		if(checkRes){
			let url = conf.baseUrl+'customer/checkLogin2',
			param={
				username: formData.username,
				password: formData.pass
			}
			uni.showLoading();
			_.request.post(url, param).then(res=>{
				uni.hideLoading();
				if(res.data.statuCode===1){
					_.storage.setItem('userinfo',res.data.result)
					uni.navigateBack()
				}
				let type = res.data.statuCode===1?'success':'error'
				this.$refs['login-toast'].show(type,res.data.msg)
			}).catch(err=>{
				console.log(err)
				uni.hideLoading();
				let msg = err.statusCode&&err.statusCode!==200? String(err.statusCode):err.errMsg
				_.help.toast(msg)
			})
		}else{
			this.$refs['login-toast'].show('error',graceChecker.error)
		}
	}
</script>

<style scoped>
	.style-login{
		margin: 0 110upx;
	}
		
	.style-login-line{
		border-bottom: 1px solid #c3c3c3;
		padding-bottom: 26upx;
		margin-bottom: 58upx;
	}
	.style-login-line+.style-login-line{
		padding-bottom: 10upx;
	}
	.ipt-group-logo_prev{
		width: 36upx;
		height: 36upx;
		margin-right: 20upx;

	}
	.ipt{
		font-size: 28upx;
		min-width: 452upx;
		padding-right: 20upx;
	}
	.btn-sec{
		width: 180upx;
		height: 70upx;
		style-login-line-height: 70upx;
		font-size: 28upx;
		color: #3c7ef6;
		text-align: center;
		border: 1px solid #3c7ef6;
		border-radius: 10upx;
		margin-right: 10upx;
	}
	.btn-submit{
		background: #3c7ef6;
		color:#fff;
		border-radius: 45upx;
	}
	.a-group{
		margin-top: 40upx;
	}
	.btn-a{
		color: #3c7ef6;
		font-size: 32upx;
	}
	.btn-a:first-child{
		margin-left: 20upx;
	}
	.btn-a:last-child{
		margin-right: 20upx;
	}
</style>
