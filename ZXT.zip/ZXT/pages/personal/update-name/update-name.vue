<template>
	<view class="content">
		<view class="style-main style-flex style-flex-column style-flex_ai-ct">
			<view class="ipt-group">
				<input class="ipt" focus placeholder="请输入昵称" />
			</view>
			<view class="btn-group person-btn-group">
				<button class="btn-submit" type="primary" @tap="handleSum">确认修改</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			handleSum(){
				uni.navigateBack({
					delta: 1
				})
			}
		}
	}
</script>

<style>
	.ipt-group{
		margin: 50upx 0;
	}
	.person-btn-group{
		width: 630upx;
	}
	.ipt{
		width: 630upx;
		border-radius: 10upx;
		background: #fff;
		font-size: 30upx;
		padding: 20upx 20upx;
	}
</style>
