<template>
	<view class="content">
		<view class="style-main style-flex style-flex-column style-flex_ai-ct">
			<view class="ipt-group style-flex style-flex-column style-flex_ai-ct">
				<input class="ipt" focus placeholder="请输入统一社会信用代码" />
				<text class="itp-text">请输入完整的统一社会信用代码，不支持模糊匹配，不区分大小写</text>
			</view>
			<view class="btn-group person-btn-group">
				<button class="btn-submit" type="primary" @tap="handleSum">确认修改</button>
			</view>
		</view>
		<toast ref="login-toast" type="error" msg="手机号/密码错误"></toast>
	</view>
</template>

<script>
	import toast from '../../../components/toast/toast.vue';
	export default {
		components: {
			toast
		},
		data() {
			return {
				
			};
		},
		methods:{
			handleSum(){
				this.$refs['login-toast'].show('notice','未找到关联供应商')
			}
		}
	}
</script>

<style>
	.ipt-group{
		margin: 50upx 0;
	}
	.person-btn-group{
		width: 630upx;
		margin-bottom: 40upx;
	}
	.ipt{
		width: 630upx;
		border-radius: 10upx;
		background: #fff;
		font-size: 30upx;
		padding: 20upx 20upx;
		box-sizing: border-box;
		height: auto;
	}
	.itp-text{
		width: 630upx;
		font-size: 26upx;
		color: #7d7d7d;
		margin-top: 30upx;
	}
</style>
