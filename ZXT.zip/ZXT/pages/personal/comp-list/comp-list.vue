<template>
	<view class="content">
		<view class="axb-ul">
			<view class="box comp-box style-flex style-flex_ai-ct style-flex_js_sp">
				<image class="comp-box-img" src="../../../static/img/person/company_logo@2x.png" mode=""></image>
				<text class="comp-box-text">钜亿科技有限公司</text>
				<view class="comp-box-btn">取消关联</view>
			</view>
			<view class="box comp-box style-flex style-flex_ai-ct style-flex_js_sp">
				<image class="comp-box-img" src="../../../static/img/person/company_logo@2x.png" mode=""></image>
				<text class="comp-box-text">钜亿科技有限公司</text>
				<view class="comp-box-btn" >取消关联</view>
			</view>
		</view>
		<view class="fixed" @tap="hanldeReg">
			申请新关联
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		onNavigationBarButtonTap:function(e){
		    uni.navigateTo({
				url:'../comp-reg-list/comp-reg-list'
			})
		},
		methods:{
			hanldeReg(){
				uni.navigateTo({
					url:'../com-reg/com-reg'
				})
			}
		}
	}
</script>

<style>
@import '../../../common/style.css';
.fixed{
	position: fixed;
	bottom: 0;
	background-color: #3c7ef6;
	width: 100%;
	text-align: center;
	padding: 28upx 0;
	font-size: 36upx;
	color: #fff;
}
</style>
