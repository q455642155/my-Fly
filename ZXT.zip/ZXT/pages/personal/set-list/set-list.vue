<template>
	<view class="content">
		<uni-popup :show="showPopup" :type="popType" v-on:hidePopup="hidePopup" >
			<view class="pop-text" @tap="handleVip">
				升级为企业账号
			</view>
		</uni-popup>
		<view class="box set-list-box">
			<view class="set-list-box-item axb-line style-flex style-flex_js_sp style-flex_ai-ct">
				<view class="left-text">
					账号ID
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">"Xgtr4ye6"</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
			<view class="set-list-box-item axb-line style-flex style-flex_js_sp style-flex_ai-ct" @tap="handleShowPopup">
				<view class="left-text">
					账号类型
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">个人账号</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
		</view>
		<view class="box set-list-box">
			<view class="set-list-box-item axb-line style-flex style-flex_js_sp style-flex_ai-ct">
				<view class="left-text">
					绑定手机
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">"135****2345"</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
			<navigator class="set-list-box-item axb-line style-flex style-flex_js_sp style-flex_ai-ct" url="../comp-list/comp-list" hover-class="navigator-hover">
				<view class="left-text">
					已关联供应商
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">3家</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</navigator>
			<view class="set-list-box-item axb-line style-flex style-flex_js_sp style-flex_ai-ct">
				<view class="left-text">
					密码设置
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">未设置</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniPopup from '../../../components/uni-popup.vue';
	export default {
		components:{
			uniPopup
		},
		data() {
			return {
				showPopup: false,
				popType:'bottom',
				msg:'升级为企业账号'
			};
		},
		methods:{
			handleShowPopup: function() {
				this.hidePopup();
				this.showPopup = true;
			},
			hidePopup: function() {
				this.showPopup = false;
			},
			handleVip(){
				console.log('区')
				uni.navigateTo({
					url: '../../co-auth/step1/step1'
				})
			}
		}
	}
</script>

<style>
@import '../../../common/style.css';
.set-list-box{
	padding: 0 50upx;
}
.set-list-box-item{
	padding: 40upx 0;
}
.pop-text{
	font-size: 34upx;
	line-height: 34upx;
	color: #414141;
	padding: 44upx 0;
}
</style>
