<template>
	<view class="content">
		<view class="axb-ul">
			<view class="box comp-box style-flex style-flex_ai-ct style-flex_js_sp">
				<image class="comp-box-img" src="../../../static/img/person/company_logo@2x.png" mode=""></image>
				<text class="comp-box-text">钜亿科技有限公司</text>
				<view class="comp-box-status" data-type="warning">审核中</view>
			</view>
			<view class="box comp-box style-flex style-flex_ai-ct style-flex_js_sp">
				<image class="comp-box-img" src="../../../static/img/person/company_logo@2x.png" mode=""></image>
				<text class="comp-box-text">钜亿科技有限公司</text>
				<view class="comp-box-status" data-type="success">已通过</view>
			</view>
			<view class="box comp-box style-flex style-flex_ai-ct style-flex_js_sp">
				<image class="comp-box-img" src="../../../static/img/person/company_logo@2x.png" mode=""></image>
				<text class="comp-box-text">钜亿科技有限公司</text>
				<view class="comp-box-status" data-type="danger" >已拒绝</view>
			</view>
			<view class="box comp-box style-flex style-flex_ai-ct style-flex_js_sp">
				<image class="comp-box-img" src="../../../static/img/person/company_logo@2x.png" mode=""></image>
				<text class="comp-box-text">钜亿科技有限公司</text>
				<view class="comp-box-status" data-type="default" >已过期</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
	}
</script>

<style>
@import '../../../common/style.css';
</style>
