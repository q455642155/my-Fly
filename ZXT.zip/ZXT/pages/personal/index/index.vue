<template>
	<view class="content">
		<view class="style-head">
			<image class="head-bg" src="../../../static/img/person/bg@2x.png" mode=""></image>
		</view>
		<view class="style-body style-flex style-flex-column style-flex_ai-ct">
			<view class="box box-1 style-flex">
				<image class="box-img" :src="avatar" mode=""></image>
				<view class="box-info style-flex style-flex-column style-flex_js-ct">
					<view class="box-info-name">爱吃榴莲的贝贝熊</view>
					<view class="box-info-local style-flex style-flex_ai-ct">
						<image class="box-info-local-img" src="../../../static/img/person/location@2x.png" mode=""></image>
						<text class="box-info-local-text">广东省深圳市龙华新区</text>
					</view>
				</view>
			</view>
			<view class="box box-2 style-flex style-flex_js_sp">
				<view class="box-2-text">接收消息推送</view>
				<switch class="box-2-switch" checked @change="switch1Change" />
			</view>
			<view class="box box-3">
				<navigator class="box-3-item axb-line style-flex style-flex_ai-ct style-flex_js_sp" url="../set-list/set-list" hover-class="navigator-hover">
					<view class="left style-flex style-flex_ai-ct">
						<image class="left-img" src="../../../static/img/person/icon01@2x.png" mode=""></image>
						<view class="box-3-text">账号设置</view>
					</view>
					<view class="right">
						<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
					</view>
				</navigator>
				<navigator class="box-3-item axb-line style-flex style-flex_ai-ct style-flex_js_sp" url="../personal-list/personal-list" hover-class="navigator-hover">
					<view class="left style-flex style-flex_ai-ct">
						<image class="left-img" src="../../../static/img/person/icon02@2x.png" mode=""></image>
						<view class="box-3-text">个人中心</view>
					</view>
					<view class="right">
						<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
					</view>
				</navigator>
				<view class="box-3-item style-flex style-flex_ai-ct style-flex_js_sp">
					<view class="left style-flex style-flex_ai-ct">
						<image class="left-img" src="../../../static/img/person/icon03@2x.png" mode=""></image>
						<view class="box-3-text">已授信功能</view>
					</view>
					<view class="right">
						<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
					</view>
				</view>
			</view>
			<view class="btn-group person-btn-group">
				<button class="btn-submit" type="danger">退出</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				avatar: '../../../static/img/person/avatar@2x.png'
			};
		}
	}
</script>

<style>
	.style-body{
		margin-top: -146upx;
	}
	.head-bg{
		width: 750upx;
		height: 200upx;
	}
	.box{
		width: 630upx;
		border-radius: 10upx;
		background: #FFFFFF;
		box-shadow: 0 0 18px rgba(60, 126, 246, 0.3);
		box-sizing: border-box;
		margin-bottom: 50upx;
	}
	.box-1{
		padding: 55upx 30upx;
		z-index: 99;
	}
	.box-info{
		margin-left: 38upx;
	}
	.box-img{
		width: 136upx;
		height: 136upx;
		border-radius: 50%;
		box-shadow: 0 0 0px 10upx rgba(60, 126, 246, 0.2);
	}
	.box-info-name{
		font-size: 30upx;
		line-height: 30upx;
		color: #414141;
		margin-bottom: 32upx;
	}
	.box-info-local-text{
		font-size: 24upx;
		color: #7d7d7d;
	}
	.box-info-local-img{
		width: 28upx;
		height: 28upx;
		margin-right: 10upx;
	}
	.box-2{
		padding: 38upx 30upx;
	}
	.box-2-text{
		font-size: 32upx;
		color: #414141;
	}
		
	.box-2-switch{
		height: 34upx;
	}
	.box-3{
		padding: 0upx 28upx;
	}
	.box-3-item{
		padding: 40upx 0;
	}
	.axb-line{
		border-bottom: 1upx solid rgba(195, 195, 195, 0.6);
	}
	.left-img{
		width: 60upx;
		height: 60upx;
		margin-right: 20upx;
	}
	.right-img{
		width: 24upx;
		height: 24upx;
	}
	.person-btn-group{
		width: 630upx;
	}
</style>
