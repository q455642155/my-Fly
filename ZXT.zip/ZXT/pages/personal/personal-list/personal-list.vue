<template>
	<view class="content">
		<view v-show="!isSelect" class="box person-box style-flex style-flex-column">
			<view class="person-item axb-line style-flex style-flex_js_sp style-flex_ai-ct">
				<view class="left-text">
					头像
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<image class="right-avatar" :src="avatar" mode=""></image>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
			<view class="person-item axb-line style-flex style-flex_js_sp style-flex_ai-ct" @tap="upName">
				<view class="left-text">
					昵称
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">未设置</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
			<view class="person-item style-flex style-flex_js_sp style-flex_ai-ct" @tap="upArea">
				<view class="left-text">
					所属地区
				</view>
				<view class="right style-flex style-flex_ai-ct">
					<text class="right-title">未设置</text>
					<image class="right-img" src="../../../static/img/person/arrow@2x.png" mode=""></image>
				</view>
			</view>
		</view>
		<view v-show="isSelect">
			<index-list @tap-val="handleTap"></index-list>
		</view>
	</view>
</template>

<script>
	import indexList from '../../../components/index-list.vue'
	export default {
		data() {
			return {
				avatar: '../../../static/img/person/avatar@2x.png',
				isSelect: false
			};
		},
		components:{
			indexList
		},
		methods:{
			upName(){
				uni.navigateTo({
					url:'../update-name/update-name'
				})
			},
			upArea(){
				this.isSelect = true
			},
			handleTap(val){
				console.log(val)
				this.isSelect = false
			}
		}
	}
</script>

<style>
	@import '../../../common/style.css';/* 列表项-左右分布 */
	.person-box{
		padding: 0 50upx;
	}
	.person-item{
		padding: 20upx 0;
	}
	.person-item+.person-item{
		padding: 40upx 0;
	}
</style>
