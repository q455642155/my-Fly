<template>
	<view>
		<web-view src="https://jurongtest.foxconn.com/JuXin-App/"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
