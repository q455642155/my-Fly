<template>
	<view  class="content">
		<back-top :is-show="isShowBkTop"></back-top>
		<detail-title :title="title" :status="status"></detail-title>
		<view class="detail-section">
			<view class="detail-section-content content">
				<view class="detail-section-content-box">
					<view class="detail-header">
						维保单详情
					</view>
					<view class="detail-body info">
						<view class="l-ul">
							<view v-for="(item,idx) in details" :key="idx" class="l-li l-line style-flex style-flex_ai-ct">
								<view class="label">{{item.title}}</view>
								<view class="text" :class="{ red: item.isRed }">{{baseData1[item.value]}}</view>
							</view>
						</view>
					</view>
				</view>
				<!-- <view class="detail-section-content-box">
					<view class="detail-header">
						维保操作信息
					</view>
					<view class="detail-body info">
						<view class="ul">
							<view class="li line style-flex style-flex_ai-ct">
								<view class="label">到达日期</view>
								<view class="text">2018/12/17</view>
							</view>
							<view class="li line style-flex style-flex_ai-ct">
								<view class="label">开始时间</view>
								<view class="text">2018/12/17</view>
							</view>
							<view class="li line style-flex style-flex_ai-ct">
								<view class="label">结束时间</view>
								<view class="text">2018/12/17</view>
							</view>
							<view class="li line style-flex style-flex_ai-ct">
								<view class="label">维保人</view>
								<view class="text">2018/12/17</view>
							</view>
							<view class="li line style-flex style-flex_ai-ct">
								<view class="label">维保记录</view>
								<view class="text red" @tap="handleRecord">点击查看</view>
							</view>
							<view class="li line style-flex">
								<view class="label">备注</view>
								<scroll-view :scroll-top="scrollTop" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
								@scroll="scroll">
								<view class="textarea">
									
										1233dafasfasf1233dafasfasf1233dafasfasf1233dafasfasf1233dafasfasf1233dafasfasf1233dafasfasf1233dafasfasf1233dafasfasf
							
								</view>
								</scroll-view>
							</view>
						</view>
					</view>
				</view> -->
				<view class="detail-section-content-box">
					<view class="detail-header">
						维保设备信息
					</view>
					<view class="detail-body info">
						<view class="l-ul">
							<view v-for="(item,idx) in details2" :key="idx" class="l-li l-line style-flex style-flex_ai-ct">
								<view class="label">{{item.title}}</view>
								<view class="text" :class="{ red: item.isRed }">{{baseData2[item.value]}}</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// 配置
	import {conf} from '../../common/config.js'

	// 函数
	import _ from '../../common/util.js'
	import throttle from 'lodash/throttle'
	
	import detailTitle from '../../components/detail/detail-title.vue';
	import backTop from '../../components/item-back-top.vue'
	export default {
		components: {
			detailTitle,
			backTop
		},
		data() {
			return {
				isShowBkTop: false,
				scrollTop: 0,
				baseData1:{},
				baseData2:{},
				title: '',// 标题
				status: 0, // 状态
				details: [{
					title: '计划编号',
					value: 'mPlanNo'
				}, {
					title: '合约单号',
					value: 'agreementCode'
				}, {
					title: '单价',
					value: 'price',
				}, {
					title: '总金额',
					value: 'totalAmount'
				}, {
					title: '维保项目',
					value: 'mDutyCodeDes'
				}, {
					title: '开始日期',
					value: 'planDt'
				}, {
					title: '备注',
					value: 'remark'
				}],
				details2: [{
					title: '设备代码',
					value: 'equipmentCode'
				}, {
					title: '规格型号',
					value: 'spec'
				}, {
					title: '设备名称',
					value: 'equipmentName',
				}, {
					title: '设备大类',
					value: 'equipmentTypeDes'
				}, {
					title: '厂区',
					value: 'areaDes'
				}, {
					title: '事业群',
					value: 'BG'
				}, {
					title: '事业处',
					value: 'BU'
				}, {
					title: '栋别',
					value: 'building'
				}, {
					title: '楼层',
					value: 'floor'
				}, {
					title: '负责人',
					value: 'reposibility'
				}, {
					title: '费用代码',
					value: 'expenseCode'
				}]
			};
		},
		onLoad: async function (option) { //option为object类型，会序列化上个页面传递的参数
			console.log(option.id); //打印出上个页面传递的参数。
			// 赋值
			this.title = option.title
			this.status = Number(option.status)
			// 获取详情
			let data = {
				"mPlanNo": option.id
			}
			let param = {
				url:'http://10.134.154.115:8011/mtform/getmplandetailinfo',
				bcJson:JSON.stringify(data)
			}
			param= JSON.stringify(param)
			try{
				const res = await _.request.getDetail(conf.url, param)
				this.baseData1 = res.data.data.planInfo
				this.baseData1.price= _.thousandth(this.baseData1.price)
				this.baseData1.totalAmount= _.thousandth(this.baseData1.totalAmount)
				this.baseData2 = res.data.data.equipInfo
			}catch(e){
				console.log(e)
				_.help.err(e.errMsg)
			}
		},
		onPageScroll:throttle(_.isShowBtn, 100,{ 'leading': false }),
		methods: {
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			handleRecord(){
				uni.navigateTo({
					url: '../maintainrecord/maintainrecord?id=1&name=uniapp'
				})
			}
		}
	}
</script>

<style>
	@import "../../common/detail.css";
	.detail-section-content-box{
		margin-bottom: 30upx;
	}
	.scroll-Y{
		width: 400upx;
		height: 120upx;
	}
	.textarea{
		min-height: 120upx;
		background: #ececec;
		word-break: break-all;
		padding: 10upx;
		font-size: 24upx;
		color: #414141;
	}
</style>
