<template>
	<view class="content">
		<page-head></page-head>
		<view class="style-login">
			<form @submit="formSubmit">
				<view class="style-flex style-flex-column">
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<image class="ipt-group-logo_prev" src="../../static/img/login/icon-phone@2x.png" mode=""></image>
						<view class="zone style-flex style-flex_ai-ct" @tap="showSinglePicker">
							<text>{{getZone}}</text>
							<image class="ipt-group-logo_after" src="../../static/img/login/arrow_down@2x.png" mode=""></image>
						</view>
						<view class="ipt">
							<input class="ipt-phone" type="number" name="tel" v-model="tel" placeholder="请输入手机号" />
						</view>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<image class="ipt-group-logo_prev" src="../../static/img/login/icon_securitycode@2x.png" mode=""></image>
						<view class="ipt style-flex style-flex_ai-ct">
							<input class="ipt-sec" type="number" name="sec" placeholder="请输入验证码" />
							<view class="btn-sec" @tap="send">{{sendMsg}}</view>
						</view>
						<toast ref="login-toast" type="error" msg="手机号/密码错误"></toast>
					</view>
					<view class="btn-group">
						<button class="btn-submit" formType="submit">提交</button>
					</view>
				</view>
			</form>
		</view>
		<mpvue-picker :themeColor="themeColor" ref="mpvuePicker" mode="selector" :deepLength="1" :pickerValueDefault="pickerValueDefault"
		 @onConfirm="onConfirm" @onCancel="onCancel" :pickerValueArray="pickerSingleArray"></mpvue-picker>
	</view>
</template>

<script>
	// 配置
	import {
		conf
	} from '../../common/config.js'
	import _ from '../../common/util.js'
	import debounce from 'lodash/debounce'
	import commonLogin from '../../common/login/common.js'
	import mpvuePicker from '../../components/mpvue-picker/mpvuePicker.vue';
	import toast from '../../components/toast/toast.vue';
	//来自 graceUI 的表单验证， 使用说明见手册 http://grace.hcoder.net/doc/info/73-3.html
	var  graceChecker = require("../../common/graceChecker.js");
	export default {
		components: {
			mpvuePicker,
			toast
		},
		data() {
			return {
				// 区号选择
				pickerValueDefault: [0],
				pickerSingleArray: [{
						label: '+86',
						value: '+86'
					},
					{
						label: '俄罗斯',
						value: '2'
					},
					{
						label: '美国',
						value: '3'
					},
					{
						label: '日本',
						value: '4'
					}
				],
				tel: '', // 手机号
				timeClock:null, // 定时器
				sendMsg: '获取验证码', // 验证码按钮显示文字
				themeColor: '#007AFF',
			};
		},
		computed:{
			getZone(){
				return this.pickerSingleArray[this.pickerValueDefault].label
			}
		},
		methods:{
			onCancel(e) {
				console.log(e)
			},
			onConfirm(e) {
				console.log(e)
				this.pickerValueDefault = e.index
			},
			// 单列
			showSinglePicker() {
				this.$refs.mpvuePicker.show()
			},
			send: debounce(commonLogin.sendVerify, 500, {leading: true,trailing: false}),
			formSubmit:debounce(formSubmit, 500, {leading: true,trailing: false}),
		}
	}
	// 提交
	function formSubmit(e){
		console.log(e)
		//将下列代码加入到对应的检查位置
		//定义表单规则
		var rule = [
			{name:"tel", checkType : "phoneno", checkRule:"",  errorMsg:"手机号错误"},
			{name:"sec", checkType : "string", checkRule:"6",  errorMsg:"请输入6位验证码"}
		];
		//进行表单检查
		var formData = e.detail.value;
		var checkRes = graceChecker.check(formData, rule);
		if(checkRes){
			let url = conf.baseUrl+'customer/register',
			param={
				mobile: this.tel,
				smsKaptcha: formData.sec
			}
			uni.redirectTo({
				url:'./success/success'
			})
// 			_.request.post(url, param).then(res=>{
// 				if(res.data.statuCode===1){
// 					uni.redirectTo({
// 						url:'./success/success'
// 					})
// 				}else{
// 					let type = res.data.statuCode===1?'success':'error'
// 					this.$refs['login-toast'].show(type,res.data.msg)
// 				}
// 			}).catch(err=>{
// 				_.help.toast(err)
// 			})
		}else{
			this.$refs['login-toast'].show('error',graceChecker.error)
		}
	}
</script>

<style scoped>
	.style-login{
		margin: 0 110upx;
	}
		
	.style-login-line{
		border-bottom: 1px solid #c3c3c3;
		padding-bottom: 26upx;
		margin-bottom: 58upx;
	}
	.style-login-line+.style-login-line{
		padding-bottom: 10upx;
	}
	.ipt-group-logo_prev{
		width: 36upx;
		height: 36upx;
		margin-right: 20upx;

	}
	.zone{
		color: #7d7d7d;
		font-size: 30upx;
		style-login-line-height: 30upx;
	}
	.zone:after{
		content: '';
		width: 1px;
		height: 30upx;
		background: #c3c3c3;
		margin: 0 10upx;
	}
	.ipt-group-logo_after{
		width: 15upx;
		height: 9upx;
		margin-left: 5upx;
	}
	.ipt{
		font-size: 28upx;
	}
	.ipt-sec{
		max-width: 280upx;
	}
	.btn-sec{
		width: 180upx;
		height: 70upx;
		line-height: 70upx;
		font-size: 28upx;
		color: #3c7ef6;
		text-align: center;
		border: 1px solid #3c7ef6;
		border-radius: 10upx;
		margin-right: 10upx;
	}
	.btn-submit{
		background: #3c7ef6;
		color:#fff;
		border-radius: 45upx;
	}
	.a-group{
		margin-top: 40upx;
	}
	.btn-a{
		color: #3c7ef6;
		font-size: 32upx;
	}
	.btn-a:first-child{
		margin-left: 20upx;
	}
	.btn-a:last-child{
		margin-right: 20upx;
	}
</style>
