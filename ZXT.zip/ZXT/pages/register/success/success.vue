<template>
	<view class="success-box style-flex style-flex_ai-ct style-flex-column">
		<image class="success-img" src="../../../static/img/login/login_successful@2x.png" mode=""></image>
		<text class="success-text">注册成功</text>
		<view class="text-box">
			<text class="text-box-main">
				<text class="red">*</text>如果你是供应商帐号管理员，可以通过企业认证升级成为企业帐号。升级流程需要准备法人身份证及企业组织机构代码。
			</text>
		</view>
		<view class="btn-group">
			<navigator url="../../index/index"  open-type="reLaunch"  hover-class="navigator-hover">
				<button class="btn-submit" type="primary"  >返回首页</button>
			</navigator>
			<navigator url="../../co-auth/step1/step1" hover-class="navigator-hover">
				<button class="btn-submit" type="primary" plain="true">升级成为企业账号</button>
			</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.success-img{
		width: 420upx;
		height: 307upx;
		margin-top: 133upx;
	}
	.success-text{
		color:#7d7d7d;
		font-size: 26upx;
		margin-top: 25upx;
	}
	.text-box{
		width: 493upx;
		font-size: 26upx;
		color:rgb(125,125,125);
		margin-top: 103upx;
	}
	.red{
		color: #f14456;
	}
	.btn-group{
		margin: 38upx;
	}
	.btn-group button{
		width: 530upx;
		border-radius: 45upx;
		margin-bottom: 30upx;
	}
	.btn-group button[type=primary]{
		color: #fff;
		background-color: #3c7ef6;
	}
	.btn-group button[type=primary][plain]{
		color: #3c7ef6;
		border: 1px solid #3c7ef6;
		background-color: rgba(0,0,0,0);
	}
</style>
