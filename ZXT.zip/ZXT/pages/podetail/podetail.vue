<template>
	<view class="content">
		<back-top :is-show="isShowBkTop"></back-top>
		<detail-title :title="baseDatas.companyName"></detail-title>
		<view class="detail-section">
			<view class="detail-section-tab">
				<uni-segmented-control :current="current" :values="items" v-on:clickItem="onClickItem" styleType="button"
				 activeColor="#007aff"></uni-segmented-control>
			</view>
			<view class="detail-section-content content">
				<view v-show="current === 0">
					<view class="detail-section-content-box">
						<view class="detail-header">
							采购方信息
						</view>
						<view class="detail-body info">
							<view class="l-ul">
								<view v-for="(item,idx) in details" :key="idx" class="l-li l-line style-flex style-flex_ai-ct">
									<view class="label">{{item.title}}</view>
									<view class="text" :class="{ red: item.isRed }">{{baseDatas[item.value]}}</view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view v-show="current === 1">
					<view class="detail-section-content-box">
						<view class="detail-header">
							采购物资列表
						</view>
						<view class="detail-body list">
							<detail-list :data="detailList"></detail-list>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// 配置
	import {conf} from '../../common/config.js'
	// 函数
	import _ from '../../common/util.js'
	import throttle from 'lodash/throttle'

	import uniSegmentedControl from '../../components/uni-segmented-control.vue';
	import detailTitle from '../../components/detail/detail-po-title.vue';
	import detailList from '../../components/detail/detail-po-list.vue';
	import backTop from '../../components/item-back-top.vue'
	export default {
		data() {
			return {
				isShowBkTop: false,
				items: [
					'基本信息',
					'采购列表'
				],
				baseDatas:{},
				current: 0,
				detailList:[
					{name:'123'},
					{name:'123'}
				],
				details: [{
					title: '订单日期',
					value: 'poDate'
				}, {
					title: '订单编号',
					value: 'poBillno'
				}, {
					title: '采购总价',
					value: 'totalAmount',
					isRed: true
				}, {
					title: '币别',
					value: 'currCode'
				}, {
					title: '税率',
					value: 'taxRate'
				}, {
					title: '采购人',
					value: 'purUser'
				}, {
					title: '采购部门',
					value: 'purDept'
				}, {
					title: '收货地址',
					value: 'receivingAddress'
				}, {
					title: '分机',
					value: 'ext'
				}, {
					title: '地区',
					value: 'area'
				}, {
					title: '收款方式',
					value: 'paymentTerm'
				}]
			};
		},
		 onLoad: async function (option) { //option为object类型，会序列化上个页面传递的参数
			console.log(option.id); //打印出上个页面传递的参数。
			// 获取详情
			let data = {
				"poBillno": option.id,
				billType: 'ecspo'
			}
			let param = {
				url:'http://10.134.154.115:8100/default/getpoinfo',
				bcJson:JSON.stringify(data)
			}
			param= JSON.stringify(param)
			try{
				const res = await _.request.getDetail(conf.url, param)
				this.baseDatas = res.data.data.master
				this.baseDatas.totalAmount= _.thousandth(this.baseDatas.totalAmount)
				this.detailList = res.data.data.details
			}catch(e){
				console.log(e)
				_.help.err(e.errMsg)
				this.loadingType = 0
				this.contentText.contentdown = this.list.length === 0 ? '下拉刷新' : '上拉显示更多'
			}
		},
		onPageScroll:throttle(_.isShowBtn, 100,{ 'leading': false }),
		components: {
			uniSegmentedControl,
			detailTitle,
			detailList,
			backTop
		},
		methods: {
			onClickItem(index) {
				if (this.current !== index) {
					this.current = index;
				}
			},
		}
	}
</script>

<style>
	@import "../../common/detail.css";

</style>
