<template>
	<view class="content">
        <view class="main">
			<view class="main-ad">
				<swiper :previous-margin="'30rpx'" :current="isActive" :next-margin="'30rpx'" indicator-active-color="#fff" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" :circular="true" @change="adChange">
					<swiper-item class="swiper-item" :class="{ active: isActive===0 } "@click="navTo('../juxin/juxin')">
						<view class="swiper-item-view">
							<image class="img" src="../../static/img/index_banner01@2x.png" mode=""></image>
						</view>
					</swiper-item>
					<swiper-item class="swiper-item" :class="{ active: isActive===1 }" @click="navTo('../maintenance/maintenance')">
						<view class="swiper-item-view">
							<image class="img" src="../../static/img/index_banner02@2x.png" mode=""></image>
						</view>
					</swiper-item>
					<swiper-item class="swiper-item" :class="{ active: isActive===2 }" @click="navTo('../poorder/poorder')">
						<view class="swiper-item-view">
							<image class="img" src="../../static/img/index_banner03@2x.png" mode=""></image>
						</view>
					</swiper-item>
				</swiper>
			</view>
			<view class="main-menu">
				<view class="style-title">
					<text class="style-title_left">供应商业务</text>
					<text class="style-title_right">| Supplier</text>
				</view>
				<view class="main-menu-list">
						<view class="style-flex style-flex_js_sp">
							<view class="style-flex style-flex-column main-menu-list-start" @click="navTo('../poorder/poorder')">
								<view class="main-img-content">
									<image class="main-menu-img" src="../../static/img/menu_01@3x.png" mode=""></image>
								</view>
								<text class="main-menu-text_header">PO单查询</text>
								<text class="main-menu-text_body">采购单信息查询</text>
							</view>
							<view class="style-flex style-flex-column" @click="navTo('../maintenance/maintenance')">
								<view class="main-img-content">
									<image class="main-menu-img" src="../../static/img/menu_02@3x.png" mode=""></image>
								</view>
								<text class="main-menu-text_header">维保查询</text>
								<text class="main-menu-text_body">维保/维修查询</text>
								
							</view>
							<view class="style-flex style-flex-column main-menu-list-end" @click="navTo('../juxin/juxin')">
								<view class="main-img-content">
									<image class="main-menu-img" src="../../static/img/menu_03@3x.png" mode=""></image>
								</view>
								<text class="main-menu-text_header">供应链金融</text>
								<text class="main-menu-text_body">钜信网</text>
								
							</view>
						</view>
				</view>
			</view>
		</view>
        <view class="nav style_bg-gray style-flex style-flex-column style-flex_ai-ct">
			<view class="nav-menu">
				<view class="style-title">
					<text class="style-title_left">集团业务</text>
					<text class="style-title_right">| Foxconn</text>
				</view>
				<view class="menu-list">
					<view class="style-flex style-flex_js_sp">
						<view class="style-flex style-flex-column main-menu-list-start" @click="navTo('../login-phone/login-phone')">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_04@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
						<view class="style-flex style-flex-column" @click="navTo('../personal/index/index')">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_05@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
							
						</view>
						<view class="style-flex style-flex-column">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_06@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
						<view class="style-flex style-flex-column main-menu-list-end">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_07@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
					</view>
				</view>
			</view>
			<view class="nav-menu">
				<view class="style-title">
					<text class="style-title_left">统计信息</text>
					<text class="style-title_right">| Statistics</text>
				</view>
				<view class="menu-list">
					<view class="style-flex style-flex_js_sp">
						<view class="style-flex style-flex-column main-menu-list-start">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_08@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
						<view class="style-flex style-flex-column">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_09@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
						<view class="style-flex style-flex-column">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_10@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
						<view class="style-flex style-flex-column main-menu-list-end">
							<view class="nav-img-content">
								<image class="nav-menu-img" src="../../static/img/menu_11@3x.png" mode=""></image>
							</view>
							<text class="nav-menu-text_header">待规划</text>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello',
				isActive: 0,
			}
		},
		onLoad() {

		},
		onNavigationBarButtonTap:function(e){
            if(e.index===1){
				uni.showModal({
					title: '当前版本',
					content: 'Version:v1.0.1,build:102',
					success: function (res) {
						if (res.confirm) {
							uni.navigateTo({
								url:'../personal/index/index'
							})
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				});
			}else{
				uni.navigateTo({
					url:'../login-phone/login-phone'
				})
			}
        },
		methods: {
			adChange:function(e){
				this.isActive = e.detail.current
			},
			navTo:function(url){
				uni.navigateTo({
					url: url
				});
			}
		}
	}
</script>

<style>
	.content{
		text-align: center;
	}
	/* 滚动区 */
	.swiper-item{
		height: 140px !important;
		margin-top: 5px;
	}
	.swiper-item.active{
		height: 100% !important;
		margin-top: 0;
	}
	.swiper-item-view>.img{
		height: 140px;
		width: 670upx;
	}
	.swiper-item.active>.swiper-item-view>.img{
		height: 150px;
	}
	/* 滚动指示点 */
	.uni-swiper-dots .uni-swiper-dot{
		width: 13px;
		height: 3px;
		border-radius: initial;
	}
	/* */
	.main{
		background: #fff;
		padding-bottom: 40upx;
	}
	/* 上部分菜单样式 */

	.main-menu{
		margin-top: 40upx;
	}
	.main-menu-list{
		margin-top: 20upx;
	}
	.main-menu-list-start{
		margin-left: 75upx;
	}
	.main-menu-list-end{
		margin-right: 75upx;
	}
	.main-img-content{
		height: 135upx;
	}
	.main-menu-img{
		width: 135upx;
		height: 135upx;
	}
	.main-menu-text_header{
		font-size: 26upx;
		color: #242424;
		margin: 20upx 0 14upx 0;
	}
	.main-menu-text_body{
		font-size: 22upx;
		color: #999;
	}
	/* 下部分菜单样式 */
	.menu-list{
		margin-top: 28upx;
	}
	.nav-menu{
		width: 710upx;
		background: #fff;
		margin-top: 20upx;
		padding: 24upx 0;
		border-radius: 5upx;
	}
	.nav-menu-text_header{
		font-size: 26upx;
		color: #242424;
		margin: 16upx 0 0 0;
	}
	.nav-img-content{
		height: 63upx;
	}
	.nav-menu-img{
		width: 63upx;
		height: 63upx;
	}
</style>
