<template>
	<view>
		<back-top :is-show="isShowBkTop"></back-top>
		<view class="record-ul">
			<view class="record-li">
				<record :idx="1"></record>
			</view>
			<view class="record-li">
				<record :idx="2"></record>
			</view>
		</view>
	</view>
</template>

<script>
	// 函数
	import {isShowBtn} from '../../common/util.js'
	import throttle from 'lodash/throttle'
	
	import record from '../../components/detail/detail-maintain-record.vue';
	import backTop from '../../components/item-back-top.vue'
	export default {
		components:{
			record,
			backTop
		},
		data() {
			return {
				isShowBkTop: false,
			};
		},
		onPageScroll:throttle(isShowBtn, 100,{ 'leading': false }),
		methods:{
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
		}
	}
</script>

<style>
	.record-ul{
		padding: 40upx 50upx;
	}
	.record-li:not(:first-child){
		margin-top: 60upx;
	}
</style>
