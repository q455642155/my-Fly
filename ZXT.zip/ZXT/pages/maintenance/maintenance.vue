<template>
	<view class="content style-flex style-flex-column style-flex_ai-ct">
		<image class="maintenance-menu-img" src="../../static/img/banner01@2x.png"  @click="navTo('../maintain/maintain')"></image>
		<image class="maintenance-menu-img" src="../../static/img/banner02@2x.png"  @click="navTo('../repair/repair')"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			navTo:function(url){
				uni.navigateTo({
					url: url
				});
			}
		}
	}
</script>

<style>
	.maintenance-menu-img{
		width: 650upx;
		height: 280upx;
		margin-top: 30upx;
	}
</style>
