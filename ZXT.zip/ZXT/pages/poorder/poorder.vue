<template>
	<view class="content">
		<back-top :is-show="isShowBkTop"></back-top>
		<!-- 排序区域 -->
		<view class="search-header style-flex style-flex_ai-ct style-flex_js_sp search-header_order">
			<search :title="'订单日期'" :status="sortPoDate" @statu-change="handleSort('sortPoDate',$event)"></search>
			<!-- <search :title="'采购总价'" :status="totalAmount" @statu-change="handleSort('totalAmount',$event)"></search> -->
			<view class="style-flex style-flex_ai-ct" @tap="showRightDrawer">
				<text class="search-header-filter-btn">筛选</text>
				<image class="search-header-filter-icon2" src="../../static/img/filtrate@3x.png" mode=""></image>
			</view>
		</view>
		<!-- 列表区域 -->
		<view class="list-box">
			<view class="list-view">
				<l-list :list="list"></l-list>
			</view>
			<!-- 错误提示 -->
			<l-err v-if="list.length===0&&showErr" :err-type="errType" :err-msg="errMsg"></l-err>
			<!-- 加载更多 -->
			<uni-load-more v-if="list.length>0|!showErr" :loadingType="loadingType" :contentText="contentText"></uni-load-more>
		</view>
		<!-- 侧滑抽屉 -->
		<uni-drawer :visible="rightDrawerVisible" mode="right" @close="closeRightDrawer">
			<view class="style-filter-content">
				<filter-header @close="closeRightDrawer"></filter-header>
				<scroll-view scroll-y class="filter-body">
					<view class="filter-body-section">
						<view class="filter-body-section-header">
							订单日期
						</view>
						<view class="filter-body-section-body style-flex style-flex-wrap">
							<filter-radio ref="radio1" :list="filterOrderTime" @change="radioChange"></filter-radio>
						</view>
					</view>
					<view class="filter-body-section">
						<view class="filter-body-section-header">
							币别
						</view>
						<view class="filter-body-section-body style-flex style-flex-wrap">
							<filter-radio ref="radio2" :multi="true" :list="filterCurrency" @change="radioChangeCur"></filter-radio>
						</view>
					</view>
				</scroll-view>
				<view class="filter-footer style-flex">
					<view class="btn btn-default" @tap="filterReset">
						重置
					</view>
					<view class="btn btn-primary" @tap="filterSub">
						确定
					</view>
				</view>
			</view>
		</uni-drawer>
	</view>
</template>
<script>
	// 配置
	import {
		conf
	} from '../../common/config.js'
	//函数
	import _ from '../../common/util.js'
	import debounce from 'lodash/debounce'
	import throttle from 'lodash/throttle'
	import orderBy from 'lodash/orderBy'
	// 函数-其它相关(po)
	import orderMain from '../../common/poorder/commons-main.js'
	// 组件
	import uniLoadMore from '../../components/uni-load-more.vue'
	import lErr from '../../components/toast/err.vue'
	import uniDrawer from '../../components/uni-drawer.vue';
	import lList from '../../components/list/list-poorder.vue'
	import search from '../../components/item-search.vue'
	import backTop from '../../components/item-back-top.vue'
	// 筛选组件
	import filterHeader from '../../components/filter/filter-header.vue'
	import filterRadio from '../../components/filter/filter-radio.vue'
	export default {
		components: {
			uniLoadMore,
			uniDrawer,
			lErr,
			lList,
			search,
			backTop,
			filterHeader,
			filterRadio
		},
		data() {
			return {
				isShowBkTop: false,
				list: [],
				// 错误提示
				showErr: 0,
				errType: '',
				errMsg: '',
				loadingType: 0,
				contentText: {
					contentdown: "上拉显示更多",
					contentrefresh: "正在加载...",
					contentnomore: "已经到底了"
				},
				searchIcons: [
					"../../static/img/arrow_default@3x.png",
					"../../static/img/arrow_down@3x.png",
					"../../static/img/arrow_up@3x.png"
				],
				// 排序条件
				sortPoDate: '', // 订单日期
				totalAmount: '', // 采购总价
				// 抽屉
				rightDrawerVisible: false,
				//当前筛选条件
				searchParam: {
					pageNum: 1,
					pageSize: 20,
					billType: 'ecspo',
					venCode: "VCN0000009",
					venAccount: "VCN0000009",
					currCode: '',
					dateStart: _.dateToString(_.getTime('1year')),
					dateEnd: _.dateToString(new Date())
				},
				// 最新筛选条件
				filterParam: {
					currCode: '',
					dateStart: _.dateToString(_.getTime('1year')),
					dateEnd: _.dateToString(new Date())
				},
				filterCurrency: [{ // 币别
					name: 'RMB',
					value: 'RMB',
					checked: 0
				}, {
					name: 'USD',
					value: 'USD',
					checked: 0
				}],
				filterOrderTime: [{ // 订单日期
					name: '过去三天',
					value: '3day',
					checked: 0
				}, {
					name: '过去一周',
					value: '1week',
					checked: 0
				}, {
					name: '过去一月',
					value: '1month',
					checked: 0
				}, {
					name: '过去半年',
					value: '6month',
					checked: 0
				}, {
					name: '过去一年',
					value: '1year',
					checked: 0
				}],
			}
		},
		onLoad() {
			// 			_.request.post('https://juxin.foxconn.com/JuXin/openapi/login/checkLogin2', {phone: '15112663977',
			//     password: '123456',
			//     kaptcha: '7896'}).then(res=>{
			// 				console.log('测试成功(正式)')
			// 				for(let t in res){
			// 					console.log(t)
			// 					console.log(res[t])
			// 				
			// 				}
			// 				console.log(res.data.msg)
			// 			}).catch(e=>{
			// 				console.log('测试失败(正式)')
			// 				for(let t in e){
			// 					console.log(t)
			// 					console.log(e[t])
			// 				
			// 				}
			// 			})
			// 			_.request.post('https://jurongtest.foxconn.com/JuXin/openapi/login/checkLogin2', {phone: '15112663977',
			// 			password: '123456',
			// 			kaptcha: '7896'}).then(res=>{
			// 						console.log('测试成功(开发)')
			// 						for(let t in res){
			// 							console.log(t)
			// 							console.log(res[t])
			// 						
			// 						}
			// 					}).catch(e=>{
			// 						console.log('测试失败(开发)')
			// 						for(let t in e){
			// 							console.log(t)
			// 							console.log(e[t])
			// 						
			// 						}
			// 					})
			this.initData()
		},
		onPageScroll: throttle(_.isShowBtn, 100, {
			'leading': false
		}),
		// 下拉刷新
		onPullDownRefresh() {
			console.log('onPullDownRefresh');
			this.initData();
		},
		// 上拉加载更多
		async onReachBottom() {
			if (this.loadingType !== 0) {
				return;
			}
			this.loadingType = 1;
			let r = await this.getData(this.searchParam.pageNum++)
			console.log(r)
		},
		onNavigationBarButtonTap(e) {
			console.log(e.index)
			uni.navigateTo({
				url: "../poordersearch/poordersearch"
			})
		},
		methods: {
			// **************************************排序相关方法****************************//
			getSortKeyArr: function() {
				let searchKey = []
				if (this.sortPoDate !== '') {
					searchKey.push('sortPoDate')
				}
				if (this.totalAmount !== '') {
					searchKey.push('totalAmount')
				}
				return searchKey
			},
			getSortValueArr: function() {
				let searchValue = []
				if (this.sortPoDate !== '') {
					searchValue.push(this.sortPoDate)
				}
				if (this.totalAmount !== '') {
					searchValue.push(this.totalAmount)
				}
				return searchValue
			},
			handleSort: debounce(handleSort, 500, {
				leading: true,
				trailing: false
			}),
			// **************************************筛选相关方法****************************//
			closeRightDrawer() {
				this.rightDrawerVisible = false;
				//#ifdef APP-PLUS
				// 开启下拉刷新
				const pages = getCurrentPages();
				const page = pages[pages.length - 1];
				const currentWebview = page.$getAppWebview();
				currentWebview.setStyle({
					pullToRefresh: {
						support: true,
						style: plus.os.name === 'Android' ? 'circle' : 'default'
					}
				});
				//#endif
			},
			showRightDrawer() {
				this.rightDrawerVisible = true;
				//#ifdef APP-PLUS
				// 关闭下拉刷新
				const pages = getCurrentPages();
				const page = pages[pages.length - 1];
				const currentWebview = page.$getAppWebview();
				currentWebview.setStyle({
					pullToRefresh: {
						support: false,
						style: plus.os.name === 'Android' ? 'circle' : 'default'
					}
				});
				//#endif
			},
			// 筛选时间修改
			radioChange(val) {
				this.filterParam.dateStart = _.dateToString(_.getTime(val))
			},
			// 筛选币别修改
			radioChangeCur(val) {
				this.filterParam.currCode = val
			},
			// 筛选重置
			filterReset: function() {
				for (let var1 in this.$refs) {
					this.$refs[var1].reset()
				}
				this.filterParam.currCode = ''
				this.filterParam.dateStart = _.dateToString(_.getTime('1year'))
			},
			// ***********************************数据获取******************************//
			// 初始化获取数据
			initData:orderMain.initData,
			// 获取数据
			getData: orderMain.getData('http://10.134.154.115:8100/default/getpolistall'),
			// 筛选提交debounce
			filterSub: debounce(filterSub, 500, {
				leading: true,
				trailing: false
			})
		}
	}
	// 排序
	function handleSort(item, val) {
		this.$data[item] = val
		// 				let sortKey = this.getSortKeyArr()
		// 				let sortValue = this.getSortValueArr()
		// 				this.list=orderBy(this.list, sortKey, sortValue)
		this.initData();
	}
	function filterSub() {
		console.log('提交')
		Object.assign(this.searchParam, this.filterParam)
		this.initData()
		this.closeRightDrawer()
	}
</script>

<style>
	@import "../../common/list.css";
	@import "../../common/search.css";
	@import "../../common/filter.css";

	.search-header_order {
		padding: 0 50upx;
	}
</style>
