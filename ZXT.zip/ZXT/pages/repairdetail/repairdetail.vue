<template>
	<view  class="content">
		<back-top :is-show="isShowBkTop"></back-top>
		<detail-title :title="title" :status="status"></detail-title>
		<view class="detail-section">
			<view class="detail-section-content content">
				<view class="detail-section-content-box">
					<view class="detail-header">
						维保单信息
					</view>
					<view class="detail-body info">
						<view class="l-ul">
							<template v-for="(item,idx) in details" >
								<view v-if="item.isemail" :key="idx" class="l-li l-line style-flex style-flex_ai-ct">
									<view class="label">{{item.title}}</view>
									<view class="text" :class="{ red: item.isRed,'style-email': item.isemail }" @touchstart="handleTouchStart(baseDatas[item.value])" @touchend="handleTouchEnd">{{baseDatas[item.value]}}</view>
								</view>
								<view v-else-if="item.textarea" :key="idx" class="l-li l-line style-flex">
									<view class="label">{{item.title}}</view>
									<scroll-view :scroll-top="scrollTop" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
									@scroll="scroll">
									<view class="textarea">
										{{baseDatas[item.value]}}
									</view>
									</scroll-view>
								</view>
								<view v-else :key="idx" class="l-li l-line style-flex style-flex_ai-ct">
									<view class="label">{{item.title}}</view>
									<view class="text" :class="{ red: item.isRed }">{{baseDatas[item.value]}}</view>
								</view>
							</template>
						</view>
					</view>
				</view>
				<view class="detail-section-content-box">
					<view class="detail-header">
						总费用信息
					</view>
					<view class="detail-body info">
						<view class="l-ul">
							<view class="l-li l-line style-flex style-flex_ai-ct">
								<view class="label">总费用</view>
								<view class="text red">{{feeDatas.totalFee}}</view>
							</view>
							<view class="l-li l-line style-flex style-flex_ai-ct">
								<view class="label">配件费用</view>
								<view class="text">{{feeDatas.itemFee}}</view>
							</view>
							<view class="l-li l-line style-flex style-flex_ai-ct">
								<view class="label">人工费用</view>
								<view class="text">{{feeDatas.laborFee}}</view>
							</view>
							<view class="l-li l-line style-flex style-flex_ai-ct">
								注：以上单位均为:(RMB)
							</view>
						</view>
					</view>
				</view>
				<view class="detail-section-content-box">
					<view class="detail-header">
						配件清单信息
					</view>
					<view class="detail-body l-list">
						<detail-list :data="detailList"></detail-list>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// 配置
	import {conf} from '../../common/config.js'
	// 函数
	import _ from '../../common/util.js'
	import throttle from 'lodash/throttle'
	
	import detailTitle from '../../components/detail/detail-title.vue';
	import detailList from '../../components/detail/detail-repair-list.vue';
	import backTop from '../../components/item-back-top.vue'
	export default {
		components: {
			detailTitle,
			detailList,
			backTop,
		},
		data() {
			return {
				isShowBkTop: false,
				scrollTop: 0,
				title: '',// 标题
				status: 0, // 状态
				details: [{
					title: '保修单号',
					value: 'mtFormCode'
				}, {
					title: '申请人',
					value: 'applyMan'
				}, {
					title: '邮箱',
					value: 'notes',
					isemail: true
				}, {
					title: '分机号码',
					value: 'tel'
				}, {
					title: '设备代码',
					value: 'equipmentCode'
				}, {
					title: '设备名称',
					value: 'equipmentName'
				}, {
					title: '设备大类',
					value: 'equipmentTypeDes'
				}, {
					title: '品牌',
					value: 'brand'
				}, {
					title: '规格',
					value: 'spec'
				}, {
					title: '事业群',
					value: 'BG'
				}, {
					title: '事业处',
					value: 'BU',
				}, {
					title: '部门',
					value: 'deptName'
				}, {
					title: '法人',
					value: 'corpName'
				}, {
					title: '栋别',
					value: 'building'
				}, {
					title: '安装位置',
					value: 'position'
				}, {
					title: '报修日期',
					value: 'applyDt'
				}, {
					title: '异常现象',
					value: 'unUsualInfo',
					textarea: true
				}, {
					title: '维修内容',
					value: 'applyMemo',
					textarea: true
				}],
				baseDatas:{},
				feeDatas:{},

				detailList:[
					{name:'123'},
					{name:'123'}
				],
			};
		},
		onLoad: async function (option) { //option为object类型，会序列化上个页面传递的参数
			console.log(option.id); //打印出上个页面传递的参数。
			// 赋值
			this.title = option.title
			this.status = Number(option.status)
			// 获取详情
			let data = {
				"mtFormCode": option.id
			}
			let param = {
				url:'http://10.134.154.115:8011/mtform/getmtformdetailinfo ',
				bcJson:JSON.stringify(data)
			}
			param= JSON.stringify(param)
			try{
				const res = await _.request.getDetail(conf.url, param)
				this.baseDatas = res.data.data.headerInfo
				this.feeDatas = dealMoneyList(res.data.data.feeInfo)
				this.detailList = res.data.data.itemInfo
			}catch(e){
				console.log(e)
				_.help.toast('出错了！')
			}
		},
		onPageScroll:throttle(_.isShowBtn, 100,{ 'leading': false }),
		methods: {
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			handleRecord(){
				uni.navigateTo({
					url: '../maintainrecord/maintainrecord?id=1&name=uniapp'
				})
			},
			// 触摸邮箱
			handleTouchStart(val){
				console.log(val)
				_.help.toast(val)
			},
			handleTouchEnd(){
				
			}
		}
	}
	function dealMoneyList(items){
		for(let item in items){
			items[item] = _.thousandth(items[item])
		}
		return items
	}
</script>

<style>
	@import "../../common/detail.css";
	.detail-section-content-box{
		margin-bottom: 30upx;
	}
	.scroll-Y{
		width: 400upx;
		height: 120upx;
	}
	.textarea{
		min-height: 120upx;
		background: #ececec;
		word-break: break-all;
		padding: 10upx;
		font-size: 24upx;
		color: #414141;
	}
	.style-email{
		color: #3C7EF6 !important;
		font-size: 14px !important;
		height: 14px;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
	}
</style>
