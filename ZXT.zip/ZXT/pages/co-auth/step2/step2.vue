<template>
	<view class="content">
		<view class="step-box">
			<steps :step="current"></steps>
		</view>
		<view class="main-box">
			<view class="main-box-1">
				<view class="style-white-box style-flex style-flex-column">
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<view class="ipt style-flex style-flex_ai-ct">
							<text class="title">供应商代码</text>
							<input class="ipt-val"  name="sec" placeholder-style="color:#bfbfbf;" placeholder="请输入供应商代码" />
						</view>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<view class="ipt style-flex style-flex_ai-ct">
							<text class="title">企业名称</text>
							<input class="ipt-val"  name="sec" placeholder-style="color:#bfbfbf;" placeholder="请输入企业名称" />
						</view>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<view class="ipt style-flex style-flex_ai-ct">
							<text class="title">统一社会信用代码</text>
							<input class="ipt-val"  name="sec" placeholder-style="color:#bfbfbf;" placeholder="请输入统一社会信用代码" />
						</view>
						<toast ref="login-toast" type="error" msg="手机号/密码错误"></toast>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<view class="ipt style-flex style-flex_ai-ct">
							<text class="title">法人姓名</text>
							<input class="ipt-val"  name="sec" placeholder-style="color:#bfbfbf;" placeholder="请输入法人姓名" />
						</view>
						<toast ref="login-toast" type="error" msg="手机号/密码错误"></toast>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<view class="ipt style-flex style-flex_ai-ct">
							<text class="title">身份证号码</text>
							<input class="ipt-val"  name="sec" placeholder-style="color:#bfbfbf;" placeholder="请输入法人身份证号码" />
						</view>
						<toast ref="login-toast" type="error" msg="手机号/密码错误"></toast>
					</view>
				</view>
			</view>
			<view class="btn-group">
				<button class="btn-submit" @tap="next">下一步</button>
			</view>
		</view>
	</view>
</template>

<script>
	import debounce from 'lodash/debounce'
	import commonLogin from '../../../common/login/common.js'
	import toast from '../../../components/toast/toast.vue';
	import steps from '../../../components/steps.vue'
	export default {
		components: {
			steps,
			toast
		},
		data() {
			return {
				current: 2, // 当前步骤
			};
		},
		methods:{
			next:debounce(next, 500, {leading: true,trailing: false}),
		}
	}
	function next(){
		uni.navigateTo({
			url:'../step3/step3'
		})
	}
</script>

<style scoped>
	.step-box{
		padding-top: 30upx;
	}
	.style-white-box{
		background: #fff;
		margin: 30upx 0 50upx 0;
		padding: 30upx 60upx;
	}
	.style-login-line:not(:last-child){
		border-bottom: 1px solid #c3c3c3;
		padding-bottom: 18upx;
		margin-bottom: 18upx;
	}
	.title{
		font-size: 28upx;
		color:#7d7d7d;
		margin-right: 44upx;
		width: 224upx;
	}
	.lable-phone{
		font-size: 30upx;
		color: #414141;
	}
	.ipt{
		font-size: 28upx;
	}
	.ipt-val{
		width: 310upx;
	}
	.btn-sec{
		width: 180upx;
		height: 70upx;
		line-height: 70upx;
		font-size: 28upx;
		color: #3c7ef6;
		text-align: center;
		border: 1px solid #3c7ef6;
		border-radius: 10upx;
		margin-right: 10upx;
	}
	.btn-submit{
		width: 630upx;
		background: #3c7ef6;
		color:#fff;
		border-radius: 45upx;
	}
</style>
