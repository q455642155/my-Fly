<template>
	<view class="content">
		<view class="step-box">
			<steps :step="current"></steps>
		</view>
		<view class="main-box">
			<view class="main-box-1">
				<view class="style-flex style-flex-column style-flex_ai-ct">
					<image class="success-img" src="../../../static/img/co/pic_sucessful@2x.png" mode=""></image>
					<text class="success-text">资料提交成功</text>
					<text class="success-text-child">企业认证资料正在审核中，大概需要3-5个工作日。</text>
				</view>
			</view>
			<view class="btn-group">
				<button class="btn-submit" @tap="next">返回首页</button>
			</view>
		</view>
	</view>
</template>

<script>
	import debounce from 'lodash/debounce'
	import commonLogin from '../../../common/login/common.js'
	import toast from '../../../components/toast/toast.vue';
	import steps from '../../../components/steps.vue'
	export default {
		components: {
			steps,
			toast
		},
		data() {
			return {
				current: 4, // 当前步骤
			};
		},
		methods:{
			next:debounce(next, 500, {leading: true,trailing: false}),
		}
	}
	function next(){
		uni.reLaunch({
			url:'../../index/index'
		})
	}
</script>

<style scoped>
	.step-box{
		padding-top: 30upx;
	}
	.success-img{
		width: 400upx;
		height: 300upx;
		margin-top: 133upx;
	}
	.success-text{
		color:#7d7d7d;
		font-size: 26upx;
		margin-top: 25upx;
	}
	.success-text-child{
		margin-top: 102upx;
		font-size: 26upx;
		line-height: 26upx;
		color:#7d7d7d;
	}
	.btn-group{
		margin-top: 30upx;
	}
	.btn-submit{
		width: 630upx;
		background: #3c7ef6;
		color:#fff;
		border-radius: 45upx;
	}
</style>
