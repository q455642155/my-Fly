<template>
	<view class="content">
		<view v-show="!croping">
		<view class="step-box">
			<steps :step="current"></steps>
		</view>
		<view class="main-box">
			<view class="main-box-1">
				<view class="style-pic style-flex style-flex-column style-flex_ai-ct">
					<view class="img-box">
						<image class="upload-img" :src="picFace" mode="" @tap="getImage('picFace')"></image>
						<view v-show="uploaded.picFace" class="img-mask style-flex style-flex_ai-ct style-flex_js-ct">
							<text class="mask-btn" @tap="handlePreview('picFace')">点击查看</text>
							<text class="mask-btn" @tap="getImage('picFace')">重新上传</text>
						</view>
					</view>
					<view class="img-box">
						<image class="upload-img" :src="picEmblem" mode="" @tap="getImage('picEmblem')"></image>
						<view v-show="uploaded.picEmblem" class="img-mask style-flex style-flex_ai-ct style-flex_js-ct">
							<text class="mask-btn" @tap="handlePreview('picFace')">点击查看</text>
							<text class="mask-btn" @tap="getImage('picFace')">重新上传</text>
						</view>
					</view>
					<view class="img-box">
						<image class="upload-img" :src="picHand" mode="" @tap="getImage('picHand')"></image>
						<view v-show="uploaded.picHand" class="img-mask style-flex style-flex_ai-ct style-flex_js-ct">
							<text class="mask-btn" @tap="handlePreview('picFace')">点击查看</text>
							<text class="mask-btn" @tap="getImage('picFace')">重新上传</text>
						</view>
					</view>
				</view>
			</view>
			<view class="btn-group">
				<button class="btn-submit" @tap="next">下一步</button>
			</view>
		</view>
		</view>
		<view class="page-body uni-content-info">
			<crop ref="crop" :croping="croping" @upcroping="uploadCroping" @upsrc="srcUpload"></crop>
		</view>
	</view>
</template>

<script>
	import debounce from 'lodash/debounce'
	import commonLogin from '../../../common/login/common.js'
	import toast from '../../../components/toast/toast.vue';
	import steps from '../../../components/steps.vue'
	import crop from '../../../components/crop/crop.vue'
	export default {
		components: {
			steps,
			toast,
			crop
		},
		data() {
			return {
				current: 3, // 当前步骤
				uploaded: {
					picFace: false,
					picEmblem: false,
					picHand: false
				}, // 手机号
				picFace:'/static/img/co/pic_face@2x.png',
				picEmblem:'/static/img/co/pic_emblem@2x.png',
				picHand:'/static/img/co/pic_hand@2x@2x.png',
				curCrop: 'picFace',
				croping: false,
			};
		},
		mounted: function () {
		
			//this.loadImage();
		
		},
		methods:{
			next:debounce(next, 500, {leading: true,trailing: false}),
			handlePreview(val){
				uni.previewImage({
					urls: [this.$data[this.curCrop]]
				});
			},
			getImage(val){
				this.curCrop = val
				console.log(this)
				this.$refs.crop.getImage()
			},
			srcUpload(val){
				console.log('地址改变了',val)
				this.$data[this.curCrop] = val
				this.uploaded[this.curCrop] =true
			},
			uploadCroping(val){
				this.croping = val
			}
		}
	}
	function next(){
		uni.navigateTo({
			url:'../step4/step4'
		})
	}
</script>
 <style>
	 page {
	 	/* background-color:#F4F5F6;
	 	height: 100%;
	 	font-size:28upx;
	 	line-height: 1.8; */
	 }
 </style>
<style scoped>
	.step-box{
		padding-top: 30upx;
	}
	.main-box{
		margin-top: 30upx;
	}
	.img-box{
		position: relative;
		height: 240upx;
		margin-bottom: 20upx;
	}
	.upload-img{
		width: 420upx;
		height: 240upx;
		border-radius: 10upx;
	}
	.img-mask{
		position:absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background: rgba(0,0,0,0.6);
		border-radius: 10upx;

	}
	.mask-btn{
		color: #fff;
		margin: 0 20upx;
	}
	.btn-group{
		margin-top: 20upx;
	}
	.btn-submit{
		width: 630upx;
		background: #3c7ef6;
		color:#fff;
		border-radius: 45upx;
	}
</style>
