<template>
	<view>
		<view class="step-box">
			<steps :step="current"></steps>
		</view>
		<view class="main-box">
			<view class="main-box-1">
				<view class="style-white-box style-flex style-flex-column">
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<text class="title">手机号码</text>
						<text class="lable-phone">135****3678</text>
					</view>
					<view class="style-login-line ipt-group style-flex style-flex_ai-ct">
						<view class="ipt style-flex style-flex_ai-ct">
							<text class="title">验证码</text>
							<input class="ipt-sec" type="number" name="sec" placeholder="请输入验证码" />
							<view class="btn-sec" @tap="send">{{sendMsg}}</view>
						</view>
						<toast ref="login-toast" type="error" msg="手机号/密码错误"></toast>
					</view>
				</view>
			</view>
			<view class="btn-group">
				<button class="btn-submit" @tap="next">下一步</button>
			</view>
		</view>
	</view>
</template>

<script>
	import commonLogin from '../../common/login/common.js'
	import toast from '../../components/toast/toast.vue';
	import steps from '../../components/steps.vue'
	export default {
		components: {
			steps,
			toast
		},
		data() {
			return {
				current: 1, // 当前步骤
				tel: '15112663977', // 手机号
				timeClock:null, // 定时器
				sendMsg: '获取验证码', // 验证码按钮显示文字
			};
		},
		methods:{
			send: commonLogin.sendVerify,
			next:next
		}
	}
	function next(){
		uni
	}
</script>

<style scoped>
	.step-box{
		margin-top: 30upx;
	}
	.style-white-box{
		background: #fff;
		margin: 30upx 0 50upx 0;
		padding: 30upx 60upx;
	}
	.style-login-line:first-child{
		border-bottom: 1px solid #c3c3c3;
		padding-bottom: 26upx;
		margin-bottom: 58upx;
	}
	.style-login-line+.style-login-line{
		padding-bottom: 10upx;
	}
	.title{
		font-size: 30upx;
		color:#7d7d7d;
		margin-right: 32upx;
		width: 120upx;
	}
	.lable-phone{
		font-size: 30upx;
		color: #414141;
	}
	.ipt{
		font-size: 28upx;
	}
	.btn-sec{
		width: 180upx;
		height: 70upx;
		line-height: 70upx;
		font-size: 28upx;
		color: #3c7ef6;
		text-align: center;
		border: 1px solid #3c7ef6;
		border-radius: 10upx;
		margin-right: 10upx;
	}
	.btn-submit{
		width: 630upx;
		background: #3c7ef6;
		color:#fff;
		border-radius: 45upx;
	}
</style>
