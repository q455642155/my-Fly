/**
 * 请求封装对象
 */
const request = {
	/**
	 * get请求
	 * @param {str} url 请求地址
	 * @param {object} data 请求参数
	 */
	get: function get(url, data) {
		return new Promise(function(resolve, reject) {

			uni.request({
				url: url, //仅为示例，并非真实接口地址。
				data: data,
				success: (res) => {
					resolve(res);
				},
				fail: (err) => {
// 					uni.showToast({
// 						icon: 'none',
// 						title: '错误:' + err.errMsg
// 					});
					reject(err);
				},
			});
		});
	},
	post: function post(url, data) {
		return new Promise(function(resolve, reject) {
			uni.request({
				url: url, //仅为示例，并非真实接口地址。
				data: data,
				method: 'POST',
				success: (res) => {
					if(res.statusCode!==200){
						reject(res)
					}
					resolve(res);
				},
				fail: (err) => {
// 					uni.showToast({
// 						icon: 'none',
// 						title: '错误:' + err.errMsg
// 					});
					reject(err);
				},
			});
		});
	},
	getDetail:function getDetail(url,data){
		return new Promise(async (resolve,reject)=>{
			// 显示加载框
			uni.showLoading({
				title: '加载中'
			});
			try{
				const res = await this.post(url, data)
				// 关闭加载框
				uni.hideLoading();
				resolve(res)
			}catch(e){
				// 关闭加载框
				uni.hideLoading();
				reject(e);
			}
		})
	}
}
/**
 * 封装Storage
 */
const storage = {
	/**
	 * 保存数据
	 */
	setItem: function(key, val) {
		uni.setStorageSync(key, val)
	},
	/**
	 * 获取数据
	 */
	getItem: function(key) {
		return uni.getStorageSync(key)
	},
	/**
	 * 移除数据
	 */
	removeItem: function(key) {
		uni.removeStorageSync(key);
	},
	/**
	 * 清空缓存数据
	 */
	clearAll: function() {
		uni.clearStorageSync()
	},
	/**
	 * 检测safari无痕模式
	 */
	checkSafariS: function() {
		try {
			this.setItem("foobar", "foobar");
		} catch (_) {
			uni.showModal({
				title: '提示',
				content: '本地储存写入错误，若为safari浏览器请关闭无痕(隐身)模式浏览。',
				success: function(res) {
					if (res.confirm) {
						console.log('用户点击确定');
					} else if (res.cancel) {
						console.log('用户点击取消');
					}
				}
			});
		}
	}
}
const help = {
	/**
	 * 弹出提示信息
	 * @param {string} text 提示内容
	 * @param {obj} config 配置项icon:String图标，有效值 "success", "loading", "none";image:String自定义图标的本地路径;mask:Boolean是否显示透明蒙层，防止触摸穿透，默认：false;duration:Number提示的延迟时间，单位毫秒，默认：1500
	 */
	toast: function(text, config) {
		// 设置默认项
		let conf = Object.assign({
			icon: 'none',
			image: '',
			mask: false,
			duration: 1500
		}, config)
		conf.title = text
		uni.showToast(conf);
	},
	err: function(val){
		if(val.indexOf('timeout')>=0){
			this.toast('网络出错了!')
		}else{
			this.toast(e)
		}
	}
}
/**重置*/
function reset(val) {
	val.map(function(item) {
		item.checked = 0
	})
}
/**
 * 千分位转换
 * @param {number} val 转换值
 */
const thousandth = function(val) {
	var regex = /(\d)(?=(\d{3})+$)/g
	var result
	if (typeof val === 'string' && val !== '') {
		let str = val
		if (str.indexOf('.') === -1) {
			result = str.replace(regex, '$1,') + '.00'
		} else {
			var newStr = str.split('.')
			var str2 = newStr[0].replace(regex, '$1,')
			if (newStr[1].length <= 1) {
				// 小数点后只有一位时
				result = str2 + '.' + newStr[1] + '0'
			} else if (newStr[1].length > 1) {
				// 小数点后两位以上时
				var decimals = newStr[1].substr(0, 2)
				result = str2 + '.' + decimals
			}
		}
	} else if (typeof val === 'number') {
		return val.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,')
	} else if (val === undefined || val === null || val === '') {
		return '- -'
	}
	return result
}
// 金额转千分位
function dealMoneyList(items,key,rekey) {
	const arr = items.map((item) => {
		item[rekey] = thousandth(item[key])
		return item
	})
	return arr
}
/**
 * 根据范围获取时间
 * @param {string} val 传入时间 3day
 */
function getTime(val) {
	switch (val) {
		case '3day':
			return new Date(new Date().setDate(new Date().getDate() - 3));
			break;
		case '1week':
			return new Date(new Date().setDate(new Date().getDate() - 7));
			break;
		case '1month':
			return new Date(new Date().setMonth(new Date().getMonth() - 1));
			break;
		case '6month':
			return new Date(new Date().setMonth(new Date().getMonth() - 6));
			break;
		case '1year':
			return new Date(new Date().setFullYear(new Date().getFullYear() - 1));
			break;
		default:
			return '';
	}
}
function dateToString(val){
	let str=''
	let date = new Date(val)
	str = `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}` //2018/1/1
	return str
}
const isShowBtn = function(val) {
	const _this = this
	if (val.scrollTop >= 200 && !_this.isShowBkTop)
		_this.isShowBkTop = true;
	else if (val.scrollTop < 200 && _this.isShowBkTop)
		_this.isShowBkTop = false;
}
// 定时器
    /**
     * @param {function} callback1 未到时执行函数 返回当前剩余间隔
     * @param {function} callback2 到时执行函数
     */
const Clock = function(callback1, callback2) {
      this.timeClock = null
      this.time = 60 //定时间隔
      this.start = function () {
        var _this = this,
          time = this.time
        this.timeClock = setInterval(function () {
          time--
          if (time > 0) {
            callback1(time) // 未到时执行函数
          } else {
            _this.end() // 关闭定时器
            callback2() // 到时执行函数
          }
        }, 1000)
      }
      this.end = function () {
		  try{
			  clearInterval(this.timeClock) // 清除定时器
			  this.timeClock = null
			  return true
		  }catch(e){
			  return e
		  }
      }
    }
export default {
	request,
	storage,
	help,
	reset,
	dealMoneyList,
	getTime,
	dateToString,
	thousandth,
	isShowBtn,
	Clock
}
export {
	request,
	storage,
	help,
	reset,
	dealMoneyList,
	getTime,
	dateToString,
	thousandth,
	isShowBtn,
	Clock
}
