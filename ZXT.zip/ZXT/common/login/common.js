// 配置
import {
	conf
} from '../config.js'
import _ from '../../common/util.js'
/**
 * 发送验证码
 */
const sendVerify = function() {
	// 是否已发送验证码
	if (this.timeClock && this.timeClock.timeClock) {
		return
	}
	let reg = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/ // 手机号正则
	// 验证手机号
	if (!reg.test(this.tel)) {
		this.$refs['login-toast'].show('error', '手机号码格式错误')
		return
	}
	let _this = this,
		phone = _this.tel,
		url = conf.baseUrl+'customer/getMsgKaptcha', // 请求地址
		param= {
			mobile: _this.tel
		}, // 请求参数
		Clock = _.Clock
	_this.timeClock = _this.timeClock ? _this.timeClock : new Clock(function(res) { // 实例化定时器
		_this.sendMsg = res + '秒'
	}, function() {
		_this.sendMsg = '发送验证码'
	})
	// common.js中request
	_.request.post(url, param).then(function(res) {
		console.log(res)
		let type = res.data.statuCode===1?'success':'error'
		_this.$refs['login-toast'].show(type,  res.data.msg)
		// 定时器启动 倒计时发送验证码
		_this.timeClock.start()
	}).catch(function(err) {
		console.log(err)
		_.help.toast('错误:' + err.errMsg)
	})
}
export default {
	sendVerify
}
