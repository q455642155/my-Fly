export const conf={
	baseUrl: 'https://jurongtest.foxconn.com/yzt/openapi/',
	url:'https://jurongtest.foxconn.com/yzt/openapi/blockChainBrower/bcMonitoring'
}