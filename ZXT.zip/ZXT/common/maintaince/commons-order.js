// **************************************排序相关方法****************************//
// 获取排序顺序数组
const getSortValueArr = function() {
	let searchValue = []
	this.order.forEach((item) => {
		if (this.$data[item] !== '') {
			searchValue.push(this.$data[item])
		}
	})
	return searchValue
}
// 获取排序查询字符串参数
const getSortSql = function() {
	let searchValue = []
	this.order.forEach((item) => {
		if (this.$data[item] !== '') {
			searchValue.push(`${item} ${this.$data[item]}`)
		}
	})
	return searchValue
}
const handleSort = function(item, val) {
	this.$data[item] = val
	// 更改排序优先级
	this.order.splice(this.order.findIndex(val => val === item), 1)
	this.order.unshift(item)
	// 重新获取数据
	this.initData()

}
export default {
	getSortValueArr,getSortSql,handleSort
}
