// 配置
import {
	conf
} from '../config.js'
import {
	request,help
} from '../util.js'
// 函数
import orderBy from 'lodash/orderBy'
// 获取公共信息
const getCommonData = async function() {
	var data = {
		"pageNum": 1,
		"pageSize": 20,
		"venCode": "VCN0021205",
		"venAccount": "",
	}
	let param = {
		url: 'http://10.134.154.115:8011/mtform/getcommonlist',
		bcJson: JSON.stringify(data)
	}
	param = JSON.stringify(param)
	console.log(param)
	console.log(conf.url)
	try {
		const res = await request.post(conf.url, param)
		this.filterType = res.data.result.equipmenttypelist
		this.filterFactor = res.data.result.arealist
		console.log('公共值获取完成')
		// 更新筛选组
		this.$refs.radio3.setItems(this.filterType)
		this.$refs.radio4.setItems(this.filterFactor)
	} catch (e) {
		console.log(e.errMsg)
	}
}
// 初始化获取数据
const initData = async function() {
	this.loadingType = 1
	this.showErr = 0
	this.list = []
	// 初始化页数
	this.searchParam.pageNum = 0
	const re = await this.getData(this.searchParam.pageNum++)
	uni.stopPullDownRefresh();
}
// 获取数据
/**
 * @description 获取数据
 * @example 
 */
const getData = function(url) {
	return async function(pageNum) {
		var data = {
			"pageNum": pageNum,
			"orderCond": this.getSortSql()
		}
		data = Object.assign({}, this.searchParam, data)
		let param = {
			url: url,
			bcJson: JSON.stringify(data)
		}
		param = JSON.stringify(param)
		console.log(param)
		try {
			const res = await request.post(conf.url, param)
			if (Number(res.data.statuCode) === 0) {
				help.toast(res.data.msg)
				this.loadingType = 2
				this.contentText.contentnomore = '没有更多数据'
				return 0
			}
			this.list = orderBy(this.list.concat(res.data.result.list), this.order, this.getSortValueArr());
			// 错误提示-未获取到数据
			if (this.list.length === 0) {
				this.showErr = 1
				this.errType = 'noData'
			}
			// 加载更多
			await timeout(500)
			this.loadingType = this.list.length < res.data.result.listCount ? 0 : 2;
			this.contentText.contentnomore = this.list.length === 0 ? '没有更多数据' : '已经到底了'
			return Promise.resolve(true)
		} catch (e) {
			console.log(e)
			// 关闭下拉加载图标
			uni.stopPullDownRefresh();
			// 错误提示-无网络
			if (e.errMsg.indexOf('timeout') >= 0 || e.errMsg.indexOf('request:fail') >= 0) {
				this.showErr = 1
				this.errType = 'noNetwork'
			}
			this.loadingType = 0
			this.contentText.contentdown = this.list.length === 0 ? `系统错误:${String(e.statusCode)}` : '网络异常,请稍后再试'
		}
	}
}
function timeout(ms) {
  return new Promise((resolve, reject) => {
    setTimeout(resolve, ms, 'done');
  });
}
export default {
	getCommonData,
	getData,
	initData
}
