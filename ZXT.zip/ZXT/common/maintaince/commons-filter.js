// 函数
import _ from '../../common/util.js'
// 筛选修改-状态
const radioChangeStatus = function(length) {
	return function(val) {
		console.log(val)
		this.filterParam.mStatus = val.length > length ? val.slice(1) : val
		this.filterParam.mStatus = JSON.stringify(this.filterParam.mStatus)
		if (val.length === 0) {
			this.filterParam.mStatus = val.length === 0 ? '' : this.filterParam.mStatus
		}
	}
}
// 筛选修改-时间
const radioChangeSartTime = function(TimeDefalut) {
	return function(val) {
		this.filterParam.dateStart = val === null ? _.dateToString(_.getTime(TimeDefalut)) : _.dateToString(_.getTime(val))
	}
}

// 筛选修改-类型
const radioChangeType = function(val) {
	this.filterParam.equipmentType = val === null ? '' : val
}
// 筛选修改-厂区
const radioChangeFactor = function(val) {
	this.filterParam.areaType = val === null ? '' : val
}
export default {
	radioChangeStatus,
	radioChangeSartTime,
	radioChangeType,
	radioChangeFactor
}
